export interface ItemStats {
  damage?: number
  critChance?: number
  critDamage?: number
  attackSpeed?: number
  projectiles?: number
  size?: number
  movementSpeed?: number
  luck?: number
  armor?: number
  health?: number
  cooldown?: number
  xpBonus?: number
  goldBonus?: number
}

export interface Item {
  id: string
  name: string
  tier: "S" | "A" | "B" | "C"
  type: string
  effect: string
  description: string
  image: string
  stats: ItemStats
  synergies: string[]
  bestWith: string[]
  rarity: "Comun" | "Raro" | "Epico" | "Legendario"
}

export interface Weapon {
  id: string
  name: string
  type: string
  tier: "S" | "A" | "B" | "C" | "D"
  description: string
  image: string
  stats: ItemStats
  evolution?: string
  synergies: string[]
}

export interface Tome {
  id: string
  name: string
  description: string
  stats: ItemStats
  maxLevel: number
  image: string
}

export interface Character {
  id: string
  name: string
  tier: "S" | "A" | "B" | "C"
  role: string
  passive: string
  passiveDesc: string
  starterWeapon: string
  image: string
  color: string
  stats: {
    health: number
    speed: number
    damage: number
    armor: number
  }
  recommendedItems: string[]
  recommendedWeapons: string[]
  recommendedTomes: string[]
}

export interface Build {
  id: number
  name: string
  character: string
  characterImage: string
  player: string
  playerAvatar: string
  region: string
  rank: number
  winRate: number
  views: number
  likes: number
  weapons: string[]
  items: string[]
  tomes: string[]
  updatedAt: string
  description: string
  playstyle: string
  difficulty: "Facil" | "Media" | "Dificil"
  gamePhase: {
    early: string
    mid: string
    late: string
  }
}

export const items: Item[] = [
  {
    id: "giant-fork",
    name: "Giant Fork",
    tier: "S",
    type: "Ofensivo",
    effect: "Hits pueden convertirse en Megacrits",
    description:
      "Un tenedor gigante encantado que tiene la posibilidad de convertir cualquier golpe en un Megacrit, causando daño masivo. Esencial para builds de crítico.",
    image: "/giant-golden-fork-pixel-art-game-item-icon.jpg",
    rarity: "Legendario",
    stats: {
      critChance: 15,
      critDamage: 200,
      damage: 10,
    },
    synergies: ["Grandma's Tonic", "CL4NK", "Ninja"],
    bestWith: ["Revolver", "Bone", "Dexecutioner"],
  },
  {
    id: "backpack",
    name: "Backpack",
    tier: "S",
    type: "Utilidad",
    effect: "+1 proyectil en todas las armas",
    description: "Una mochila mágica que duplica los proyectiles de todas tus armas. Multiplica efectivamente tu DPS.",
    image: "/magical-purple-backpack-pixel-art-game-item-icon-g.jpg",
    rarity: "Legendario",
    stats: {
      projectiles: 1,
    },
    synergies: ["Quantity Tome", "Revolver", "Bananarang"],
    bestWith: ["Firestaff", "Lightning Staff", "Shuriken"],
  },
  {
    id: "cursed-doll",
    name: "Cursed Doll",
    tier: "S",
    type: "Ofensivo",
    effect: "30% HP max/seg a enemigos cercanos",
    description:
      "Una muñeca maldita que drena la vida de los enemigos cercanos. El daño escala con el HP máximo del enemigo, haciéndolo devastador contra jefes.",
    image: "/creepy-voodoo-doll-dark-magic-pixel-art-game-item-.jpg",
    rarity: "Legendario",
    stats: {
      damage: 30,
    },
    synergies: ["Ice Crystal", "Aura", "Noelle"],
    bestWith: ["Frostwalker", "Aura", "Flamewalker"],
  },
  {
    id: "dragonfire",
    name: "Dragonfire",
    tier: "S",
    type: "Ofensivo",
    effect: "15% chance de invocar fuego de dragón",
    description:
      "Un cristal de dragón antiguo que invoca llamaradas devastadoras al golpear enemigos. El fuego causa quemadura continua.",
    image: "/dragon-fire-crystal-red-flame-pixel-art-game-item-.jpg",
    rarity: "Legendario",
    stats: {
      damage: 25,
      critChance: 5,
    },
    synergies: ["Firestaff", "Fox", "Attack Speed Tome"],
    bestWith: ["Firestaff", "Flamewalker", "Battery"],
  },
  {
    id: "grandmas-tonic",
    name: "Grandma's Tonic",
    tier: "A",
    type: "Ofensivo",
    effect: "Críticos 50% chance de explotar",
    description:
      "El secreto de la abuela: cada golpe crítico tiene 50% de probabilidad de causar una explosión que daña enemigos cercanos.",
    image: "/purple-magic-potion-bottle-pixel-art-game-item-ico.jpg",
    rarity: "Epico",
    stats: {
      critDamage: 50,
      damage: 15,
    },
    synergies: ["Giant Fork", "CL4NK", "Crit Chance Tome"],
    bestWith: ["Revolver", "Bone", "Giant Fork"],
  },
  {
    id: "ice-crystal",
    name: "Ice Crystal",
    tier: "A",
    type: "Control",
    effect: "7.5% chance de congelar enemigos",
    description:
      "Un cristal de hielo eterno que puede congelar enemigos en el lugar, haciéndolos vulnerables a más daño.",
    image: "/blue-ice-crystal-frozen-magic-pixel-art-game-item-.jpg",
    rarity: "Epico",
    stats: {
      damage: 5,
      cooldown: -5,
    },
    synergies: ["Noelle", "Frostwalker", "Cursed Doll"],
    bestWith: ["Frostwalker", "Aura", "Cursed Doll"],
  },
  {
    id: "mirror",
    name: "Mirror",
    tier: "A",
    type: "Defensivo",
    effect: "Refleja daño e invulnerabilidad temporal",
    description:
      "Un espejo mágico que refleja el daño recibido a los atacantes y te otorga un breve período de invulnerabilidad.",
    image: "/magic-mirror-shield-golden-frame-pixel-art-game-it.jpg",
    rarity: "Epico",
    stats: {
      armor: 20,
      damage: 10,
    },
    synergies: ["Sir Oofie", "Armor Tome", "Calcium"],
    bestWith: ["Sword", "Phantom Shroud", "Armor Tome"],
  },
  {
    id: "clover",
    name: "Clover",
    tier: "A",
    type: "Suerte",
    effect: "Aumenta significativamente la suerte",
    description:
      "Un trébol de cuatro hojas encantado que aumenta dramáticamente tu suerte, mejorando drops y chances de crítico.",
    image: "/four-leaf-clover-lucky-green-glowing-pixel-art-gam.jpg",
    rarity: "Epico",
    stats: {
      luck: 50,
      critChance: 5,
    },
    synergies: ["Fox", "Credit Card", "XP Tome"],
    bestWith: ["Credit Card", "Giant Fork", "Backpack"],
  },
  {
    id: "credit-card",
    name: "Credit Card",
    tier: "A",
    type: "Economia",
    effect: "Más oro y mejores drops",
    description: "Una tarjeta de crédito mágica sin límite que atrae el oro y mejora la calidad de los drops.",
    image: "/golden-credit-card-shiny-diamond-pixel-art-game-it.jpg",
    rarity: "Epico",
    stats: {
      goldBonus: 30,
      luck: 20,
    },
    synergies: ["Clover", "Fox", "XP Tome"],
    bestWith: ["Clover", "Backpack", "XP Tome"],
  },
  {
    id: "turbo-socks",
    name: "Turbo Socks",
    tier: "B",
    type: "Velocidad",
    effect: "+15% velocidad de movimiento",
    description: "Calcetines aerodinámicos que te permiten moverte más rápido. Esencial para builds de velocidad.",
    image: "/speed-socks-blue-lightning-fast-pixel-art-game-ite.jpg",
    rarity: "Raro",
    stats: {
      movementSpeed: 15,
    },
    synergies: ["Calcium", "Turbo Skates", "Movement Speed Tome"],
    bestWith: ["Turbo Skates", "Phantom Shroud", "Slippery Ring"],
  },
  {
    id: "turbo-skates",
    name: "Turbo Skates",
    tier: "B",
    type: "Velocidad",
    effect: "+20% velocidad de movimiento",
    description: "Patines turbo que te hacen increíblemente rápido. Combina con Turbo Socks para máxima velocidad.",
    image: "/roller-skates-wheels-fast-red-pixel-art-game-item-.jpg",
    rarity: "Raro",
    stats: {
      movementSpeed: 20,
    },
    synergies: ["Calcium", "Turbo Socks", "Movement Speed Tome"],
    bestWith: ["Turbo Socks", "Phantom Shroud", "Calcium"],
  },
  {
    id: "battery",
    name: "Battery",
    tier: "B",
    type: "Ataque",
    effect: "+10% velocidad de ataque",
    description: "Una batería eléctrica que acelera tus ataques. Perfecta para builds de ataque rápido.",
    image: "/electric-battery-yellow-lightning-power-pixel-art-.jpg",
    rarity: "Raro",
    stats: {
      attackSpeed: 10,
    },
    synergies: ["Bandit", "Attack Speed Tome", "Joe's Dagger"],
    bestWith: ["Joe's Dagger", "Time Bracelet", "Dexecutioner"],
  },
  {
    id: "joes-dagger",
    name: "Joe's Dagger",
    tier: "B",
    type: "Ataque",
    effect: "+8% velocidad de ataque y daño",
    description: "La daga legendaria de Joe, un artefacto que aumenta tanto la velocidad como el daño de tus ataques.",
    image: "/sharp-dagger-knife-blade-silver-pixel-art-game-ite.jpg",
    rarity: "Raro",
    stats: {
      attackSpeed: 8,
      damage: 8,
    },
    synergies: ["Bandit", "Battery", "Time Bracelet"],
    bestWith: ["Battery", "Dexecutioner", "Attack Speed Tome"],
  },
  {
    id: "phantom-shroud",
    name: "Phantom Shroud",
    tier: "A",
    type: "Defensivo",
    effect: "Chance de esquivar ataques",
    description: "Un manto fantasmal que te permite atravesar ataques enemigos ocasionalmente.",
    image: "/ghost-cloak-phantom-purple-translucent-pixel-art-g.jpg",
    rarity: "Epico",
    stats: {
      armor: 10,
      movementSpeed: 5,
    },
    synergies: ["Calcium", "Slippery Ring", "Mirror"],
    bestWith: ["Slippery Ring", "Turbo Socks", "Mirror"],
  },
  {
    id: "slippery-ring",
    name: "Slippery Ring",
    tier: "B",
    type: "Evasion",
    effect: "Los enemigos te pierden de vista",
    description: "Un anillo mágico que te hace resbaladizo, dificultando que los enemigos te persigan.",
    image: "/magic-ring-blue-glow-slippery-pixel-art-game-item-.jpg",
    rarity: "Raro",
    stats: {
      movementSpeed: 10,
      armor: 5,
    },
    synergies: ["Phantom Shroud", "Calcium", "Turbo Socks"],
    bestWith: ["Phantom Shroud", "Turbo Socks", "Turbo Skates"],
  },
  {
    id: "time-bracelet",
    name: "Time Bracelet",
    tier: "B",
    type: "Utilidad",
    effect: "Reduce cooldowns de habilidades",
    description: "Un brazalete que manipula el tiempo, reduciendo el tiempo de espera entre ataques.",
    image: "/placeholder.svg?height=64&width=64",
    rarity: "Raro",
    stats: {
      cooldown: -15,
      attackSpeed: 5,
    },
    synergies: ["Cooldown Tome", "Battery", "Bandit"],
    bestWith: ["Battery", "Cooldown Tome", "Joe's Dagger"],
  },
  {
    id: "black-hole",
    name: "Black Hole",
    tier: "S",
    type: "Control",
    effect: "Atrae enemigos cercanos hacia ti",
    description: "Crea un agujero negro que atrae constantemente a los enemigos, perfecto para combos de área.",
    image: "/placeholder.svg?height=64&width=64",
    rarity: "Legendario",
    stats: {
      size: 25,
      cooldown: -10,
    },
    synergies: ["Dexecutioner", "Aura", "Cursed Doll"],
    bestWith: ["Dexecutioner", "Aura", "Frostwalker"],
  },
  {
    id: "golden-apple",
    name: "Golden Apple",
    tier: "A",
    type: "Supervivencia",
    effect: "+25% salud máxima",
    description: "Una manzana dorada mítica que aumenta permanentemente tu salud máxima.",
    image: "/placeholder.svg?height=64&width=64",
    rarity: "Epico",
    stats: {
      health: 25,
      armor: 5,
    },
    synergies: ["Sir Oofie", "Health Tome", "Mirror"],
    bestWith: ["Mirror", "Phantom Shroud", "Armor Tome"],
  },
]

export const weapons: Weapon[] = [
  {
    id: "frostwalker",
    name: "Frostwalker",
    type: "Area",
    tier: "A",
    description: "Congela y daña enemigos en un área. El arma inicial de Noelle.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 20, cooldown: -10, size: 15 },
    synergies: ["Ice Crystal", "Cursed Doll", "Size Tome"],
  },
  {
    id: "firestaff",
    name: "Firestaff",
    type: "Proyectil",
    tier: "D",
    description: "Lanza bolas de fuego que queman enemigos. El arma inicial de Fox. Bajo tier pero escalable.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 25, attackSpeed: 10 },
    synergies: ["Dragonfire", "Backpack", "Damage Tome"],
  },
  {
    id: "lightning-staff",
    name: "Lightning Staff",
    type: "Cadena",
    tier: "A",
    description: "Dispara rayos que saltan entre enemigos.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 18, projectiles: 1 },
    synergies: ["Backpack", "Quantity Tome", "Battery"],
  },
  {
    id: "aura",
    name: "Aura",
    type: "Area",
    tier: "A",
    description: "Crea un aura que daña continuamente a enemigos cercanos.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 15, size: 20 },
    synergies: ["Cursed Doll", "Size Tome", "Damage Tome"],
  },
  {
    id: "bananarang",
    name: "Bananarang",
    type: "Boomerang",
    tier: "B",
    description: "Un plátano que vuelve, golpeando enemigos dos veces.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 22, projectiles: 1 },
    synergies: ["Backpack", "Quantity Tome", "Size Tome"],
  },
  {
    id: "dexecutioner",
    name: "Dexecutioner",
    type: "Melee",
    tier: "S",
    description:
      "Hacha de ejecución devastadora. Daño masivo, piercing, puede one-shot cualquier enemigo. El arma inicial de Bandit.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 45, attackSpeed: 15, critChance: 10 },
    synergies: ["Battery", "Joe's Dagger", "Attack Speed Tome", "Black Hole"],
  },
  {
    id: "revolver",
    name: "Revolver",
    type: "Proyectil",
    tier: "A",
    description: "Dispara balas de alto daño con buena probabilidad de crítico.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 28, critChance: 10 },
    synergies: ["Giant Fork", "Grandma's Tonic", "Crit Chance Tome"],
  },
  {
    id: "flamewalker",
    name: "Flamewalker",
    type: "Trail",
    tier: "A",
    description: "Deja un rastro de fuego al moverte.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 20, movementSpeed: 10 },
    synergies: ["Dragonfire", "Turbo Socks", "Movement Speed Tome"],
  },
  {
    id: "bone",
    name: "Bone",
    type: "Proyectil",
    tier: "B",
    description: "Lanza huesos que rebotan. El arma inicial de Calcium.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 24, projectiles: 1, critChance: 5 },
    synergies: ["Giant Fork", "Backpack", "Quantity Tome"],
  },
  {
    id: "sword",
    name: "Sword",
    type: "Melee",
    tier: "B",
    description: "Espada clásica con buen daño. El arma inicial de Sir Oofie.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 35, size: 10 },
    synergies: ["Mirror", "Armor Tome", "Size Tome"],
  },
  {
    id: "bow",
    name: "Bow",
    type: "Proyectil",
    tier: "B",
    description: "Arco de largo alcance con flechas rápidas.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 20, attackSpeed: 12 },
    synergies: ["Backpack", "Attack Speed Tome", "Quantity Tome"],
  },
  {
    id: "shuriken",
    name: "Shuriken",
    type: "Proyectil",
    tier: "A",
    description: "Estrellas ninja rápidas. El arma inicial de Ninja.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 15, attackSpeed: 20, critChance: 8 },
    synergies: ["Giant Fork", "Backpack", "Crit Chance Tome"],
  },
  {
    id: "magic-staff",
    name: "Magic Staff",
    type: "Proyectil",
    tier: "C",
    description: "Bastón mágico básico. El arma inicial de Witch.",
    image: "/placeholder.svg?height=64&width=64",
    stats: { damage: 18, cooldown: -8, size: 5 },
    synergies: ["Cooldown Tome", "Size Tome", "Damage Tome"],
  },
]

export const tomes: Tome[] = [
  {
    id: "size",
    name: "Size",
    description: "+10% tamaño de ataques por nivel",
    stats: { size: 10 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "damage",
    name: "Damage",
    description: "+8% daño por nivel",
    stats: { damage: 8 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "cooldown",
    name: "Cooldown",
    description: "-5% tiempo de recarga por nivel",
    stats: { cooldown: -5 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "xp",
    name: "XP",
    description: "+10% experiencia por nivel",
    stats: { xpBonus: 10 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "quantity",
    name: "Quantity",
    description: "+1 proyectil por nivel",
    stats: { projectiles: 1 },
    maxLevel: 3,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "attack-speed",
    name: "Attack Speed",
    description: "+8% velocidad de ataque por nivel",
    stats: { attackSpeed: 8 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "movement-speed",
    name: "Movement Speed",
    description: "+8% velocidad de movimiento por nivel",
    stats: { movementSpeed: 8 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "crit-chance",
    name: "Crit Chance",
    description: "+5% probabilidad de crítico por nivel",
    stats: { critChance: 5 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "armor",
    name: "Armor",
    description: "+10 armadura por nivel",
    stats: { armor: 10 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "health",
    name: "Health",
    description: "+15 salud por nivel",
    stats: { health: 15 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
  {
    id: "luck",
    name: "Luck",
    description: "+8% suerte por nivel",
    stats: { luck: 8 },
    maxLevel: 5,
    image: "/placeholder.svg?height=48&width=48",
  },
]

export const characters: Character[] = [
  {
    id: "noelle",
    name: "Noelle",
    tier: "S",
    role: "Mago de Hielo",
    passive: "Enduring",
    passiveDesc: "+1% Tamaño por nivel, daño aumenta por enemigo congelado",
    starterWeapon: "Frostwalker",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-cyan-500 to-blue-600",
    stats: { health: 100, speed: 100, damage: 110, armor: 90 },
    recommendedItems: ["Ice Crystal", "Cursed Doll", "Giant Fork", "Backpack"],
    recommendedWeapons: ["Frostwalker", "Lightning Staff", "Aura", "Bananarang"],
    recommendedTomes: ["Size", "Damage", "Cooldown", "XP"],
  },
  {
    id: "fox",
    name: "Fox (Kitsune)",
    tier: "S",
    role: "Suerte/RNG",
    passive: "RNG Blessing",
    passiveDesc: "+1% Suerte por nivel",
    starterWeapon: "Firestaff",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-orange-500 to-red-600",
    stats: { health: 90, speed: 110, damage: 100, armor: 85 },
    recommendedItems: ["Clover", "Credit Card", "Backpack", "Giant Fork"],
    recommendedWeapons: ["Firestaff", "Lightning Staff", "Bananarang", "Aura"],
    recommendedTomes: ["Quantity", "Damage", "Cooldown", "XP"],
  },
  {
    id: "bandit",
    name: "Bandit",
    tier: "A",
    role: "DPS Velocidad",
    passive: "Quick Draw",
    passiveDesc: "+1% Velocidad de ataque por nivel",
    starterWeapon: "Dexecutioner",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-purple-500 to-pink-600",
    stats: { health: 95, speed: 105, damage: 115, armor: 80 },
    recommendedItems: ["Battery", "Joe's Dagger", "Time Bracelet", "Giant Fork"],
    recommendedWeapons: ["Dexecutioner", "Revolver", "Aura", "Flamewalker"],
    recommendedTomes: ["Attack Speed", "Damage", "Cooldown", "XP"],
  },
  {
    id: "calcium",
    name: "Calcium",
    tier: "A",
    role: "Velocidad/Evasion",
    passive: "Speed Demon",
    passiveDesc: "Daño escala con velocidad de movimiento. Velocidad se reduce al recibir daño.",
    starterWeapon: "Bone",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-gray-400 to-gray-600",
    stats: { health: 85, speed: 130, damage: 100, armor: 70 },
    recommendedItems: ["Turbo Socks", "Turbo Skates", "Phantom Shroud", "Slippery Ring"],
    recommendedWeapons: ["Bone", "Revolver", "Flamewalker", "Bow"],
    recommendedTomes: ["Movement Speed", "Attack Speed", "Quantity", "Damage"],
  },
  {
    id: "sir-oofie",
    name: "Sir Oofie",
    tier: "A",
    role: "Tank",
    passive: "Reinforced",
    passiveDesc: "+1% Armadura por nivel",
    starterWeapon: "Sword",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-yellow-500 to-amber-600",
    stats: { health: 130, speed: 85, damage: 95, armor: 120 },
    recommendedItems: ["Mirror", "Phantom Shroud", "Giant Fork", "Cursed Doll", "Golden Apple"],
    recommendedWeapons: ["Sword", "Lightning Staff", "Aura", "Flamewalker"],
    recommendedTomes: ["Armor", "Health", "Damage", "Size"],
  },
  {
    id: "cl4nk",
    name: "CL4NK",
    tier: "S",
    role: "Critico/DPS",
    passive: "Crit Happens",
    passiveDesc: "+1% Crítico por nivel. Builds de crit son devastadoras.",
    starterWeapon: "Revolver",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-emerald-500 to-teal-600",
    stats: { health: 100, speed: 95, damage: 105, armor: 100 },
    recommendedItems: ["Giant Fork", "Grandma's Tonic", "Dragonfire", "Mirror"],
    recommendedWeapons: ["Revolver", "Bone", "Aura", "Flamewalker"],
    recommendedTomes: ["Crit Chance", "Damage", "Attack Speed", "Quantity"],
  },
  {
    id: "ninja",
    name: "Ninja",
    tier: "A",
    role: "Asesino/Burst",
    passive: "Shadow Strike",
    passiveDesc: "Críticos causan daño extra explosivo",
    starterWeapon: "Shuriken",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-slate-600 to-slate-800",
    stats: { health: 80, speed: 120, damage: 120, armor: 75 },
    recommendedItems: ["Giant Fork", "Grandma's Tonic", "Backpack", "Battery"],
    recommendedWeapons: ["Shuriken", "Revolver", "Bow", "Dexecutioner"],
    recommendedTomes: ["Crit Chance", "Damage", "Attack Speed", "Quantity"],
  },
  {
    id: "witch",
    name: "Witch",
    tier: "B",
    role: "Support/Control",
    passive: "Hex Master",
    passiveDesc: "Maldiciones duran más y causan más efecto",
    starterWeapon: "Magic Staff",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-violet-500 to-purple-700",
    stats: { health: 90, speed: 100, damage: 100, armor: 85 },
    recommendedItems: ["Cursed Doll", "Ice Crystal", "Clover", "Backpack"],
    recommendedWeapons: ["Magic Staff", "Lightning Staff", "Aura", "Frostwalker"],
    recommendedTomes: ["Cooldown", "Damage", "Size", "XP"],
  },
  {
    id: "megachad",
    name: "Megachad",
    tier: "B",
    role: "Bruiser",
    passive: "Chad Energy",
    passiveDesc: "+1% HP por nivel, regeneración pasiva",
    starterWeapon: "Frostwalker",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-red-500 to-rose-600",
    stats: { health: 150, speed: 80, damage: 90, armor: 110 },
    recommendedItems: ["Golden Apple", "Mirror", "Phantom Shroud", "Cursed Doll"],
    recommendedWeapons: ["Frostwalker", "Aura", "Sword", "Flamewalker"],
    recommendedTomes: ["Health", "Armor", "Damage", "Size"],
  },
  {
    id: "ogre",
    name: "Ogre",
    tier: "C",
    role: "Tank Lento",
    passive: "Thick Skin",
    passiveDesc: "Muy tanky pero muy lento. Reduce daño recibido.",
    starterWeapon: "Sword",
    image: "/placeholder.svg?height=200&width=200",
    color: "from-green-600 to-green-800",
    stats: { health: 180, speed: 60, damage: 85, armor: 140 },
    recommendedItems: ["Golden Apple", "Mirror", "Cursed Doll", "Phantom Shroud"],
    recommendedWeapons: ["Sword", "Aura", "Frostwalker", "Flamewalker"],
    recommendedTomes: ["Health", "Armor", "Size", "Damage"],
  },
]

export const topBuilds: Build[] = [
  {
    id: 1,
    name: "Ice Queen Domination",
    character: "Noelle",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "IceMaster_KR",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "KR",
    rank: 1,
    winRate: 94.2,
    views: 125400,
    likes: 8932,
    weapons: ["Frostwalker", "Lightning Staff", "Aura", "Bananarang"],
    items: ["Giant Fork", "Backpack", "Ice Crystal", "Cursed Doll"],
    tomes: ["Size", "Damage", "Cooldown", "XP"],
    updatedAt: "Hace 2 días",
    description:
      "La build definitiva de Noelle que aprovecha su pasiva de tamaño y congelación. El combo Ice Crystal + Cursed Doll es devastador contra grupos.",
    playstyle:
      "Controla el campo de batalla congelando oleadas de enemigos mientras tu Cursed Doll drena su vida. Maximiza el tamaño de Frostwalker para cubrir más área.",
    difficulty: "Media",
    gamePhase: {
      early: "Prioriza upgrades de Frostwalker y busca Ice Crystal temprano",
      mid: "Consigue Backpack y empieza a stackear Size Tome",
      late: "Con Giant Fork y Cursed Doll, los jefes caen rápidamente",
    },
  },
  {
    id: 2,
    name: "Bullet Hell CL4NK",
    character: "CL4NK",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "RobotGod_NA",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "NA",
    rank: 2,
    winRate: 91.8,
    views: 98200,
    likes: 7421,
    weapons: ["Revolver", "Bone", "Aura", "Flamewalker"],
    items: ["Grandma's Tonic", "Giant Fork", "Dragonfire", "Mirror"],
    tomes: ["Crit Chance", "Damage", "Attack Speed", "Quantity"],
    updatedAt: "Hace 1 día",
    description:
      "Convierte la pantalla en un caos de proyectiles. La pasiva de CL4NK hace que cada bala sea potencialmente letal con críticos masivos.",
    playstyle:
      "Agresivo y caótico. Mantente en movimiento constante mientras tus proyectiles llenan la pantalla. Los críticos con Giant Fork causan Megacrits devastadores.",
    difficulty: "Dificil",
    gamePhase: {
      early: "Mejora Revolver inmediatamente, busca Crit Chance Tome",
      mid: "Giant Fork es prioridad absoluta, luego Grandma's Tonic",
      late: "Con todo el stack de crit, cada disparo puede ser un Megacrit explosivo",
    },
  },
  {
    id: 3,
    name: "Fox Luck Master",
    character: "Fox",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "LuckyFox_EU",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "EU",
    rank: 3,
    winRate: 89.5,
    views: 87600,
    likes: 6234,
    weapons: ["Firestaff", "Lightning Staff", "Bananarang", "Aura"],
    items: ["Clover", "Credit Card", "Backpack", "Giant Fork"],
    tomes: ["Quantity", "Damage", "Cooldown", "XP"],
    updatedAt: "Hace 3 días",
    description:
      "Aprovecha la suerte de Fox para conseguir items legendarios rápidamente y dominar con proyectiles múltiples.",
    playstyle:
      "Farming eficiente. Tu alta suerte te da mejores drops, así que prioriza XP y oro temprano para escalar más rápido que otros builds.",
    difficulty: "Facil",
    gamePhase: {
      early: "Clover y Credit Card son tu prioridad para maximizar drops",
      mid: "Con tu suerte alta, los legendarios aparecerán más frecuentemente",
      late: "Backpack + Quantity Tome = pantalla llena de proyectiles",
    },
  },
  {
    id: 4,
    name: "Speed Demon Calcium",
    character: "Calcium",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "BoneRunner_JP",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "JP",
    rank: 4,
    winRate: 88.1,
    views: 76400,
    likes: 5102,
    weapons: ["Bone", "Revolver", "Flamewalker", "Bow"],
    items: ["Turbo Socks", "Turbo Skates", "Phantom Shroud", "Slippery Ring"],
    tomes: ["Movement Speed", "Attack Speed", "Quantity", "Damage"],
    updatedAt: "Hace 5 días",
    description:
      "La velocidad es poder con Calcium. Mientras más rápido te muevas, más daño causas. Imposible de atrapar.",
    playstyle:
      "Kiting constante. Nunca pares de moverte. Tu daño escala con velocidad, así que cuanto más corras, más fuerte eres.",
    difficulty: "Dificil",
    gamePhase: {
      early: "Turbo Socks es obligatorio, luego Movement Speed Tome",
      mid: "Añade Turbo Skates y Phantom Shroud para evasión",
      late: "A máxima velocidad eres intocable y tu daño es enorme",
    },
  },
  {
    id: 5,
    name: "Immortal Knight",
    character: "Sir Oofie",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "TankMaster_EU",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "EU",
    rank: 5,
    winRate: 87.3,
    views: 65200,
    likes: 4890,
    weapons: ["Sword", "Lightning Staff", "Aura", "Flamewalker"],
    items: ["Mirror", "Phantom Shroud", "Giant Fork", "Cursed Doll", "Golden Apple"],
    tomes: ["Armor", "Health", "Damage", "Size"],
    updatedAt: "Hace 4 días",
    description: "Un tanque inmortal que refleja daño mientras sus auras destruyen todo a su alrededor.",
    playstyle:
      "Métete en medio de los enemigos y deja que te golpeen. Mirror refleja el daño mientras Cursed Doll y Aura los destruyen.",
    difficulty: "Facil",
    gamePhase: {
      early: "Armor Tome y Health Tome para sobrevivir",
      mid: "Mirror es clave para reflejar daño masivo",
      late: "Eres prácticamente inmortal, solo camina entre los enemigos",
    },
  },
  {
    id: 6,
    name: "Critical Assassin",
    character: "Ninja",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "ShadowBlade_JP",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "JP",
    rank: 6,
    winRate: 86.7,
    views: 58300,
    likes: 4210,
    weapons: ["Shuriken", "Revolver", "Bow", "Dexecutioner"],
    items: ["Giant Fork", "Grandma's Tonic", "Backpack", "Battery"],
    tomes: ["Crit Chance", "Damage", "Attack Speed", "Quantity"],
    updatedAt: "Hace 6 días",
    description: "Explosiones críticas constantes. Cada golpe tiene potencial de eliminar grupos enteros de enemigos.",
    playstyle:
      "Burst damage extremo. Tus críticos causan daño extra por la pasiva, y con Giant Fork pueden ser Megacrits.",
    difficulty: "Media",
    gamePhase: {
      early: "Crit Chance Tome es obligatorio desde el inicio",
      mid: "Giant Fork transforma tus críticos en Megacrits",
      late: "Grandma's Tonic hace que cada crítico explote, limpiando pantalla",
    },
  },
  {
    id: 7,
    name: "Relentless Bandit",
    character: "Bandit",
    characterImage: "/placeholder.svg?height=100&width=100",
    player: "SpeedDemon_NA",
    playerAvatar: "/placeholder.svg?height=40&width=40",
    region: "NA",
    rank: 7,
    winRate: 85.9,
    views: 52100,
    likes: 3890,
    weapons: ["Dexecutioner", "Aura", "Revolver", "Flamewalker"],
    items: ["Joe's Dagger", "Battery", "Time Bracelet", "Black Hole"],
    tomes: ["Attack Speed", "Damage", "Cooldown", "XP"],
    updatedAt: "Hace 1 semana",
    description: "Dexecutioner + Black Hole = combo devastador. Atrae enemigos y los ejecuta instantáneamente.",
    playstyle:
      "La velocidad de ataque crece con cada nivel. Con Dexecutioner S-tier y Black Hole, atraes y eliminas hordas enteras.",
    difficulty: "Media",
    gamePhase: {
      early: "Mejora Dexecutioner siempre, busca Battery y Joe's Dagger",
      mid: "Black Hole cambia el juego - atrae enemigos hacia tu Dexecutioner",
      late: "Con stacks de attack speed, eres una máquina de matar imparable",
    },
  },
]

// Funciones de utilidad
export function getItemById(id: string): Item | undefined {
  return items.find((item) => item.id === id)
}

export function getItemByName(name: string): Item | undefined {
  return items.find((item) => item.name.toLowerCase() === name.toLowerCase())
}

export function getWeaponById(id: string): Weapon | undefined {
  return weapons.find((weapon) => weapon.id === id)
}

export function getWeaponByName(name: string): Weapon | undefined {
  return weapons.find((weapon) => weapon.name.toLowerCase() === name.toLowerCase())
}

export function getTomeByName(name: string): Tome | undefined {
  return tomes.find((tome) => tome.name.toLowerCase() === name.toLowerCase())
}

export function getTomeById(id: string): Tome | undefined {
  return tomes.find((tome) => tome.id === id)
}

export function getCharacterById(id: string): Character | undefined {
  return characters.find((char) => char.id === id)
}

export function getCharacterByName(name: string): Character | undefined {
  return characters.find((char) => char.name.toLowerCase().includes(name.toLowerCase()))
}

export function getBuildById(id: number): Build | undefined {
  return topBuilds.find((build) => build.id === id)
}

export function calculateBuildStats(weaponNames: string[], itemNames: string[], tomeNames: string[]) {
  const stats: ItemStats = {
    damage: 0,
    critChance: 0,
    critDamage: 0,
    attackSpeed: 0,
    projectiles: 0,
    size: 0,
    movementSpeed: 0,
    luck: 0,
    armor: 0,
    health: 0,
    cooldown: 0,
    xpBonus: 0,
    goldBonus: 0,
  }

  weaponNames.forEach((name) => {
    const weapon = getWeaponByName(name)
    if (weapon) {
      Object.entries(weapon.stats).forEach(([key, value]) => {
        if (value) stats[key as keyof ItemStats] = (stats[key as keyof ItemStats] || 0) + value
      })
    }
  })

  itemNames.forEach((name) => {
    const item = getItemByName(name)
    if (item) {
      Object.entries(item.stats).forEach(([key, value]) => {
        if (value) stats[key as keyof ItemStats] = (stats[key as keyof ItemStats] || 0) + value
      })
    }
  })

  tomeNames.forEach((name) => {
    const tome = getTomeByName(name)
    if (tome) {
      Object.entries(tome.stats).forEach(([key, value]) => {
        if (value) stats[key as keyof ItemStats] = (stats[key as keyof ItemStats] || 0) + value
      })
    }
  })

  return stats
}

export function searchAll(query: string) {
  const q = query.toLowerCase()
  return {
    characters: characters.filter(
      (c) =>
        c.name.toLowerCase().includes(q) || c.role.toLowerCase().includes(q) || c.passive.toLowerCase().includes(q),
    ),
    items: items.filter(
      (i) => i.name.toLowerCase().includes(q) || i.effect.toLowerCase().includes(q) || i.type.toLowerCase().includes(q),
    ),
    weapons: weapons.filter(
      (w) =>
        w.name.toLowerCase().includes(q) || w.type.toLowerCase().includes(q) || w.description.toLowerCase().includes(q),
    ),
    builds: topBuilds.filter(
      (b) =>
        b.name.toLowerCase().includes(q) || b.character.toLowerCase().includes(q) || b.player.toLowerCase().includes(q),
    ),
  }
}

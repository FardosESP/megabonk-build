import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { CharacterGrid } from "@/components/character-grid"
import { TopBuilds } from "@/components/top-builds"
import { ItemTierList } from "@/components/item-tier-list"
import { BuildCreator } from "@/components/build-creator"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <CharacterGrid />
      <TopBuilds />
      <ItemTierList />
      <BuildCreator />
      <Footer />
    </main>
  )
}

"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { items, weapons, tomes, type Item } from "@/lib/game-data"
import { ItemDetailModal } from "@/components/item-detail-modal"
import { Sparkles, Sword, BookOpen } from "lucide-react"

export default function ItemsPage() {
  const [selectedItem, setSelectedItem] = useState<Item | null>(null)
  const [itemType, setItemType] = useState("items")
  const [tierFilter, setTierFilter] = useState("all")

  const tierColors: Record<string, string> = {
    S: "bg-yellow-500/20 text-yellow-400 border-yellow-500/50",
    A: "bg-orange-500/20 text-orange-400 border-orange-500/50",
    B: "bg-blue-500/20 text-blue-400 border-blue-500/50",
    C: "bg-gray-500/20 text-gray-400 border-gray-500/50",
    D: "bg-red-500/20 text-red-400 border-red-500/50",
  }

  const rarityColors: Record<string, string> = {
    Comun: "text-gray-400",
    Raro: "text-blue-400",
    Epico: "text-purple-400",
    Legendario: "text-yellow-400",
  }

  const filteredItems = tierFilter === "all" ? items : items.filter((i) => i.tier === tierFilter)
  const filteredWeapons = tierFilter === "all" ? weapons : weapons.filter((w) => w.tier === tierFilter)

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-8 text-center">
          <h1 className="mb-4 text-4xl font-bold text-foreground">Base de Datos de Items</h1>
          <p className="text-muted-foreground">Todos los items, armas y tomos del juego con sus estadísticas</p>
        </div>

        {/* Tipo de item */}
        <Tabs value={itemType} onValueChange={setItemType} className="mb-6">
          <TabsList className="mx-auto grid w-full max-w-md grid-cols-3 bg-secondary">
            <TabsTrigger value="items" className="gap-2">
              <Sparkles className="h-4 w-4" /> Items
            </TabsTrigger>
            <TabsTrigger value="weapons" className="gap-2">
              <Sword className="h-4 w-4" /> Armas
            </TabsTrigger>
            <TabsTrigger value="tomes" className="gap-2">
              <BookOpen className="h-4 w-4" /> Tomos
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Filtros tier */}
        {itemType !== "tomes" && (
          <div className="mb-6 flex flex-wrap justify-center gap-2">
            <Button
              size="sm"
              variant={tierFilter === "all" ? "default" : "outline"}
              onClick={() => setTierFilter("all")}
            >
              Todos
            </Button>
            {["S", "A", "B", "C", ...(itemType === "weapons" ? ["D"] : [])].map((tier) => (
              <Button
                key={tier}
                size="sm"
                variant={tierFilter === tier ? "default" : "outline"}
                onClick={() => setTierFilter(tier)}
              >
                Tier {tier}
              </Button>
            ))}
          </div>
        )}

        {/* Items */}
        {itemType === "items" && (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredItems.map((item) => (
              <Card
                key={item.id}
                id={item.id}
                className="cursor-pointer border-border bg-card transition-all hover:border-primary"
                onClick={() => setSelectedItem(item)}
              >
                <CardContent className="p-4">
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-secondary">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="h-12 w-12 object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-foreground">{item.name}</h3>
                        <Badge className={tierColors[item.tier]}>{item.tier}</Badge>
                      </div>
                      <p className={`text-xs ${rarityColors[item.rarity]}`}>{item.rarity}</p>
                    </div>
                  </div>
                  <p className="mb-2 text-sm text-primary">{item.effect}</p>
                  <div className="flex flex-wrap gap-1">
                    {Object.entries(item.stats)
                      .slice(0, 3)
                      .map(
                        ([key, value]) =>
                          value && (
                            <Badge key={key} variant="outline" className="text-[10px]">
                              +{value}
                              {key !== "projectiles" && key !== "armor" && key !== "health" ? "%" : ""} {key}
                            </Badge>
                          ),
                      )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Armas */}
        {itemType === "weapons" && (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredWeapons.map((weapon) => (
              <Card key={weapon.id} className="border-border bg-card">
                <CardContent className="p-4">
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-secondary">
                      <img
                        src={weapon.image || "/placeholder.svg"}
                        alt={weapon.name}
                        className="h-12 w-12 object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-foreground">{weapon.name}</h3>
                        <Badge className={tierColors[weapon.tier]}>{weapon.tier}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{weapon.type}</p>
                    </div>
                  </div>
                  <p className="mb-2 text-sm text-muted-foreground">{weapon.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {Object.entries(weapon.stats).map(
                      ([key, value]) =>
                        value && (
                          <Badge key={key} variant="outline" className="text-[10px]">
                            +{value}
                            {key !== "projectiles" ? "%" : ""} {key}
                          </Badge>
                        ),
                    )}
                  </div>
                  {weapon.synergies.length > 0 && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      Sinergias: {weapon.synergies.slice(0, 3).join(", ")}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Tomos */}
        {itemType === "tomes" && (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {tomes.map((tome) => (
              <Card key={tome.id} className="border-border bg-card">
                <CardContent className="p-4">
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-500/10">
                      <img
                        src={tome.image || "/placeholder.svg"}
                        alt={tome.name}
                        className="h-10 w-10 object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground">{tome.name}</h3>
                      <p className="text-xs text-blue-400">Max nivel: {tome.maxLevel}</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{tome.description}</p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {Object.entries(tome.stats).map(
                      ([key, value]) =>
                        value && (
                          <Badge
                            key={key}
                            variant="outline"
                            className="border-blue-500/30 bg-blue-500/10 text-xs text-blue-400"
                          >
                            {value > 0 ? "+" : ""}
                            {value}
                            {key !== "projectiles" ? "%" : ""} por nivel
                          </Badge>
                        ),
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      <ItemDetailModal item={selectedItem} isOpen={!!selectedItem} onClose={() => setSelectedItem(null)} />

      <Footer />
    </div>
  )
}

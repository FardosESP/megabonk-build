"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { topBuilds, type Build } from "@/lib/game-data"

export default function BuildsPage() {
  const [selectedBuild, setSelectedBuild] = useState<Build | null>(null)
  const [regionFilter, setRegionFilter] = useState("all")

  const filteredBuilds = regionFilter === "all" 
    ? topBuilds 
    : topBuilds.filter(b => b.region === regionFilter)

  const regions = ["all", "KR", "NA", "EU", "JP"]
  const regionNames: Record<string, string> = {
    all: "Todas",
    KR: "Korea",
    NA: "NA",
    EU: "Europa",
    JP: "Japón"
  }

  const difficultyColors: Record<string, string> = {
    Facil: "bg-green-500/20 text-green-400",
    Media: "bg-yellow-500/20 text-yellow-400",
    Dificil: "bg-red-500/20 text-red-400",
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="mx-auto max-\

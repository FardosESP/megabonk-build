"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { characters, getWeaponByName, getItemByName, getTomeByName } from "@/lib/game-data"
import { Sword, Shield, Zap, Wind, Heart, Sparkles } from "lucide-react"

export default function CharactersPage() {
  const [selectedTier, setSelectedTier] = useState("all")
  const [selectedCharacter, setSelectedCharacter] = useState<(typeof characters)[0] | null>(null)

  const filteredCharacters = selectedTier === "all" ? characters : characters.filter((c) => c.tier === selectedTier)

  const tierColors: Record<string, string> = {
    S: "bg-gradient-to-r from-yellow-500 to-amber-500 text-black",
    A: "bg-gradient-to-r from-orange-500 to-red-500 text-white",
    B: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white",
    C: "bg-gradient-to-r from-gray-500 to-gray-600 text-white",
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-8 text-center">
          <h1 className="mb-4 text-4xl font-bold text-foreground">Personajes de MegaBonk</h1>
          <p className="text-muted-foreground">Descubre todos los personajes, sus habilidades y las mejores builds</p>
        </div>

        {/* Filtros por tier */}
        <div className="mb-8 flex flex-wrap justify-center gap-2">
          <Button variant={selectedTier === "all" ? "default" : "outline"} onClick={() => setSelectedTier("all")}>
            Todos
          </Button>
          {["S", "A", "B", "C"].map((tier) => (
            <Button
              key={tier}
              variant={selectedTier === tier ? "default" : "outline"}
              onClick={() => setSelectedTier(tier)}
              className={selectedTier === tier ? tierColors[tier] : ""}
            >
              Tier {tier}
            </Button>
          ))}
        </div>

        {/* Grid de personajes */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredCharacters.map((char) => (
            <Card
              key={char.id}
              id={char.id}
              className="group cursor-pointer border-border bg-card transition-all hover:border-primary hover:shadow-lg hover:shadow-primary/20"
              onClick={() => setSelectedCharacter(char)}
            >
              <CardContent className="p-4">
                <div className={`relative mb-4 overflow-hidden rounded-lg bg-gradient-to-br ${char.color} p-4`}>
                  <Badge className={`absolute right-2 top-2 ${tierColors[char.tier]}`}>{char.tier}</Badge>
                  <img
                    src={char.image || "/placeholder.svg"}
                    alt={char.name}
                    className="mx-auto h-32 w-32 object-contain transition-transform group-hover:scale-110"
                  />
                </div>

                <h3 className="text-lg font-bold text-foreground">{char.name}</h3>
                <p className="text-sm text-muted-foreground">{char.role}</p>

                <div className="mt-3 rounded-lg bg-secondary p-2">
                  <p className="text-xs font-medium text-primary">{char.passive}</p>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{char.passiveDesc}</p>
                </div>

                <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                  <Sword className="h-3 w-3" />
                  <span>{char.starterWeapon}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      {/* Modal de detalle de personaje */}
      <Dialog open={!!selectedCharacter} onOpenChange={() => setSelectedCharacter(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto border-border bg-card sm:max-w-2xl">
          {selectedCharacter && (
            <>
              <DialogHeader>
                <div className={`flex items-center gap-4 rounded-lg bg-gradient-to-r ${selectedCharacter.color} p-4`}>
                  <img
                    src={selectedCharacter.image || "/placeholder.svg"}
                    alt={selectedCharacter.name}
                    className="h-24 w-24 rounded-full border-2 border-white/30 object-cover"
                  />
                  <div className="text-white">
                    <div className="flex items-center gap-2">
                      <DialogTitle className="text-2xl text-white">{selectedCharacter.name}</DialogTitle>
                      <Badge className={tierColors[selectedCharacter.tier]}>Tier {selectedCharacter.tier}</Badge>
                    </div>
                    <p className="opacity-90">{selectedCharacter.role}</p>
                    <p className="mt-1 text-sm opacity-80">
                      <span className="font-semibold">{selectedCharacter.passive}:</span>{" "}
                      {selectedCharacter.passiveDesc}
                    </p>
                  </div>
                </div>
              </DialogHeader>

              <Tabs defaultValue="stats" className="mt-4">
                <TabsList className="grid w-full grid-cols-3 bg-secondary">
                  <TabsTrigger value="stats">Estadísticas</TabsTrigger>
                  <TabsTrigger value="build">Build Recomendada</TabsTrigger>
                  <TabsTrigger value="tips">Tips</TabsTrigger>
                </TabsList>

                <TabsContent value="stats" className="space-y-4">
                  <div className="grid gap-4">
                    <div className="flex items-center gap-3">
                      <Heart className="h-5 w-5 text-red-400" />
                      <span className="w-24 text-sm text-muted-foreground">Salud</span>
                      <Progress value={selectedCharacter.stats.health} className="flex-1" />
                      <span className="w-12 text-right text-sm font-bold text-foreground">
                        {selectedCharacter.stats.health}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Wind className="h-5 w-5 text-cyan-400" />
                      <span className="w-24 text-sm text-muted-foreground">Velocidad</span>
                      <Progress value={selectedCharacter.stats.speed} className="flex-1" />
                      <span className="w-12 text-right text-sm font-bold text-foreground">
                        {selectedCharacter.stats.speed}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Zap className="h-5 w-5 text-yellow-400" />
                      <span className="w-24 text-sm text-muted-foreground">Daño</span>
                      <Progress value={selectedCharacter.stats.damage} className="flex-1" />
                      <span className="w-12 text-right text-sm font-bold text-foreground">
                        {selectedCharacter.stats.damage}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-gray-400" />
                      <span className="w-24 text-sm text-muted-foreground">Armadura</span>
                      <Progress value={selectedCharacter.stats.armor} className="flex-1" />
                      <span className="w-12 text-right text-sm font-bold text-foreground">
                        {selectedCharacter.stats.armor}
                      </span>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="build" className="space-y-4">
                  <div>
                    <h4 className="mb-2 font-semibold text-foreground">Armas Recomendadas</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedCharacter.recommendedWeapons.map((w) => {
                        const weapon = getWeaponByName(w)
                        return (
                          <div key={w} className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2">
                            <img src={weapon?.image || "/placeholder.svg"} alt={w} className="h-8 w-8 object-contain" />
                            <span className="text-sm text-foreground">{w}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-2 font-semibold text-foreground">Items Recomendados</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedCharacter.recommendedItems.map((i) => {
                        const item = getItemByName(i)
                        return (
                          <div key={i} className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2">
                            <img src={item?.image || "/placeholder.svg"} alt={i} className="h-8 w-8 object-contain" />
                            <span className="text-sm text-foreground">{i}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-2 font-semibold text-foreground">Tomos Recomendados</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedCharacter.recommendedTomes.map((t) => {
                        const tome = getTomeByName(t)
                        return (
                          <div key={t} className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2">
                            <img src={tome?.image || "/placeholder.svg"} alt={t} className="h-6 w-6 object-contain" />
                            <span className="text-sm text-foreground">{t}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tips" className="space-y-3">
                  <div className="rounded-lg bg-primary/10 p-3">
                    <p className="text-sm text-foreground">
                      <Sparkles className="mr-2 inline h-4 w-4 text-primary" />
                      <strong>Arma inicial:</strong> {selectedCharacter.starterWeapon} - prioriza mejorarla en los
                      primeros niveles.
                    </p>
                  </div>
                  <div className="rounded-lg bg-accent/10 p-3">
                    <p className="text-sm text-foreground">
                      <Sparkles className="mr-2 inline h-4 w-4 text-accent" />
                      La pasiva <strong>{selectedCharacter.passive}</strong> escala con cada nivel, haciéndote más
                      fuerte conforme avanzas.
                    </p>
                  </div>
                  <div className="rounded-lg bg-secondary p-3">
                    <p className="text-sm text-muted-foreground">
                      Combina items que sinergicen con tu pasiva para maximizar el potencial de {selectedCharacter.name}
                      .
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  )
}

"use client"

import { Zap, Shield, TrendingUp, Heart } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { type Character, getItemByName, getWeaponByName } from "@/lib/game-data"

interface CharacterDetailModalProps {
  character: Character | null
  isOpen: boolean
  onClose: () => void
}

const tierColors: Record<string, string> = {
  S: "bg-gradient-to-r from-yellow-500 to-amber-500 text-black",
  A: "bg-gradient-to-r from-orange-500 to-red-500 text-white",
  B: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white",
  C: "bg-gradient-to-r from-gray-500 to-gray-600 text-white",
}

export function CharacterDetailModal({ character, isOpen, onClose }: CharacterDetailModalProps) {
  if (!character) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto border-border bg-card sm:max-w-xl">
        <DialogHeader>
          <div className="flex items-start gap-4">
            <div className={`relative h-24 w-24 overflow-hidden rounded-xl bg-gradient-to-br ${character.color}`}>
              <img
                src={character.image || "/placeholder.svg"}
                alt={character.name}
                className="h-full w-full object-cover mix-blend-overlay"
              />
            </div>
            <div className="flex-1">
              <div className="mb-2 flex items-center gap-2">
                <DialogTitle className="text-2xl font-bold text-foreground">{character.name}</DialogTitle>
                <Badge className={tierColors[character.tier]}>Tier {character.tier}</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-border text-muted-foreground">
                  {character.role}
                </Badge>
                <Badge className="bg-primary/20 text-primary">{character.starterWeapon}</Badge>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Pasiva */}
          <div className="rounded-lg bg-primary/10 p-4">
            <h4 className="mb-1 text-sm font-semibold text-primary">{character.passive}</h4>
            <p className="text-sm text-foreground">{character.passiveDesc}</p>
          </div>

          <Separator className="bg-border" />

          {/* Stats base */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Estadísticas Base</h4>
            <div className="space-y-3">
              <div>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <Heart className="h-4 w-4 text-red-400" /> Salud
                  </span>
                  <span className="font-medium text-foreground">{character.stats.health}</span>
                </div>
                <Progress value={character.stats.health} className="h-2" />
              </div>
              <div>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <TrendingUp className="h-4 w-4 text-cyan-400" /> Velocidad
                  </span>
                  <span className="font-medium text-foreground">{character.stats.speed}</span>
                </div>
                <Progress value={character.stats.speed} className="h-2" />
              </div>
              <div>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <Zap className="h-4 w-4 text-yellow-400" /> Daño
                  </span>
                  <span className="font-medium text-foreground">{character.stats.damage}</span>
                </div>
                <Progress value={character.stats.damage} className="h-2" />
              </div>
              <div>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <Shield className="h-4 w-4 text-gray-400" /> Armadura
                  </span>
                  <span className="font-medium text-foreground">{character.stats.armor}</span>
                </div>
                <Progress value={character.stats.armor} className="h-2" />
              </div>
            </div>
          </div>

          <Separator className="bg-border" />

          {/* Armas recomendadas */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Armas Recomendadas</h4>
            <div className="grid grid-cols-2 gap-3">
              {character.recommendedWeapons.map((weaponName) => {
                const weapon = getWeaponByName(weaponName)
                return (
                  <div key={weaponName} className="flex items-center gap-2 rounded-lg bg-secondary p-2">
                    <img
                      src={weapon?.image || `/placeholder.svg?height=32&width=32&query=${weaponName}`}
                      alt={weaponName}
                      className="h-8 w-8 object-contain"
                    />
                    <span className="text-sm text-foreground">{weaponName}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Items recomendados */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Items Recomendados</h4>
            <div className="grid grid-cols-2 gap-3">
              {character.recommendedItems.map((itemName) => {
                const item = getItemByName(itemName)
                return (
                  <div key={itemName} className="flex items-center gap-2 rounded-lg bg-secondary p-2">
                    <img
                      src={item?.image || `/placeholder.svg?height=32&width=32&query=${itemName}`}
                      alt={itemName}
                      className="h-8 w-8 object-contain"
                    />
                    <span className="text-sm text-foreground">{itemName}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Tomos recomendados */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Tomos Recomendados</h4>
            <div className="flex flex-wrap gap-2">
              {character.recommendedTomes.map((tomeName) => (
                <Badge key={tomeName} className="bg-blue-500/20 text-blue-400">
                  {tomeName}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

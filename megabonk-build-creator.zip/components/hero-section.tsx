import { Sparkles, Trophy } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />

      <div className="relative mx-auto max-w-7xl px-4 text-center">
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="text-sm text-primary">Actualizado con el último parche</span>
        </div>

        <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground md:text-6xl lg:text-7xl">
          Crea las mejores builds de{" "}
          <span className="bg-gradient-to-r from-primary to-orange-400 bg-clip-text text-transparent">MegaBonk</span>
        </h1>

        <p className="mx-auto mb-8 max-w-2xl text-pretty text-lg text-muted-foreground">
          Descubre las builds meta de los mejores jugadores del mundo, explora combinaciones de personajes, armas e
          items, y crea tu propia build personalizada.
        </p>

        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Trophy className="mr-2 h-5 w-5" />
            Ver Top Builds
          </Button>
          <Button size="lg" variant="outline" className="border-border bg-secondary text-foreground hover:bg-muted">
            Crear Mi Build
          </Button>
        </div>

        <div className="mt-12 flex items-center justify-center gap-8 text-center">
          <div>
            <p className="text-3xl font-bold text-foreground">12+</p>
            <p className="text-sm text-muted-foreground">Personajes</p>
          </div>
          <div className="h-12 w-px bg-border" />
          <div>
            <p className="text-3xl font-bold text-foreground">50+</p>
            <p className="text-sm text-muted-foreground">Items</p>
          </div>
          <div className="h-12 w-px bg-border" />
          <div>
            <p className="text-3xl font-bold text-foreground">10K+</p>
            <p className="text-sm text-muted-foreground">Builds Creadas</p>
          </div>
        </div>
      </div>
    </section>
  )
}

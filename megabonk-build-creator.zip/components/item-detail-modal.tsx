"use client"

import type React from "react"

import { Sparkles, Zap, Shield, Target, TrendingUp } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { type Item, items, weapons, characters } from "@/lib/game-data"

interface ItemDetailModalProps {
  item: Item | null
  isOpen: boolean
  onClose: () => void
}

const tierColors: Record<string, string> = {
  S: "bg-gradient-to-r from-yellow-500 to-amber-500 text-black",
  A: "bg-gradient-to-r from-orange-500 to-red-500 text-white",
  B: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white",
  C: "bg-gradient-to-r from-gray-500 to-gray-600 text-white",
}

const rarityColors: Record<string, string> = {
  Comun: "text-gray-400",
  Raro: "text-blue-400",
  Epico: "text-purple-400",
  Legendario: "text-yellow-400",
}

const statIcons: Record<string, React.ReactNode> = {
  damage: <Zap className="h-4 w-4 text-red-400" />,
  critChance: <Target className="h-4 w-4 text-orange-400" />,
  critDamage: <Sparkles className="h-4 w-4 text-yellow-400" />,
  attackSpeed: <TrendingUp className="h-4 w-4 text-green-400" />,
  projectiles: <Sparkles className="h-4 w-4 text-blue-400" />,
  armor: <Shield className="h-4 w-4 text-gray-400" />,
  movementSpeed: <TrendingUp className="h-4 w-4 text-cyan-400" />,
  luck: <Sparkles className="h-4 w-4 text-purple-400" />,
  size: <TrendingUp className="h-4 w-4 text-pink-400" />,
  cooldown: <TrendingUp className="h-4 w-4 text-blue-400" />,
  health: <Shield className="h-4 w-4 text-green-400" />,
  goldBonus: <Sparkles className="h-4 w-4 text-yellow-400" />,
  xpBonus: <Sparkles className="h-4 w-4 text-green-400" />,
}

const statNames: Record<string, string> = {
  damage: "Daño",
  critChance: "Prob. Crítico",
  critDamage: "Daño Crítico",
  attackSpeed: "Vel. Ataque",
  projectiles: "Proyectiles",
  armor: "Armadura",
  movementSpeed: "Vel. Movimiento",
  luck: "Suerte",
  size: "Tamaño",
  cooldown: "Cooldown",
  health: "Salud",
  goldBonus: "Bonus Oro",
  xpBonus: "Bonus XP",
}

export function ItemDetailModal({ item, isOpen, onClose }: ItemDetailModalProps) {
  if (!item) return null

  // Encontrar items sinérgicos
  const synergyItems = item.synergies
    .map(
      (name) =>
        items.find((i) => i.name === name) ||
        weapons.find((w) => w.name === name) ||
        characters.find((c) => c.name === name),
    )
    .filter(Boolean)

  // Encontrar mejores combinaciones
  const bestWithItems = item.bestWith
    .map((name) => items.find((i) => i.name === name) || weapons.find((w) => w.name === name))
    .filter(Boolean)

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto border-border bg-card sm:max-w-xl">
        <DialogHeader>
          <div className="flex items-start gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-xl border border-border bg-secondary">
              <img src={item.image || "/placeholder.svg"} alt={item.name} className="h-16 w-16 object-contain" />
            </div>
            <div className="flex-1">
              <div className="mb-2 flex items-center gap-2">
                <DialogTitle className="text-2xl font-bold text-foreground">{item.name}</DialogTitle>
                <Badge className={tierColors[item.tier]}>Tier {item.tier}</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-border text-muted-foreground">
                  {item.type}
                </Badge>
                <span className={`text-sm font-medium ${rarityColors[item.rarity]}`}>{item.rarity}</span>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Efecto principal */}
          <div className="rounded-lg bg-primary/10 p-4">
            <p className="text-sm font-medium text-primary">{item.effect}</p>
          </div>

          {/* Descripción */}
          <div>
            <h4 className="mb-2 text-sm font-semibold text-foreground">Descripción</h4>
            <p className="text-sm text-muted-foreground">{item.description}</p>
          </div>

          <Separator className="bg-border" />

          {/* Stats */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Estadísticas</h4>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(item.stats).map(([key, value]) => {
                if (!value) return null
                const isPositive = key === "cooldown" ? value < 0 : value > 0
                return (
                  <div key={key} className="flex items-center gap-2 rounded-lg bg-secondary p-3">
                    {statIcons[key]}
                    <span className="text-sm text-muted-foreground">{statNames[key]}:</span>
                    <span className={`text-sm font-bold ${isPositive ? "text-accent" : "text-red-400"}`}>
                      {isPositive && key !== "cooldown" ? "+" : ""}
                      {value}
                      {key !== "projectiles" && key !== "armor" && key !== "health" ? "%" : ""}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>

          <Separator className="bg-border" />

          {/* Sinergias */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Sinergias</h4>
            <p className="mb-3 text-xs text-muted-foreground">Este item funciona especialmente bien con:</p>
            <div className="flex flex-wrap gap-2">
              {item.synergies.map((synergy) => (
                <Badge key={synergy} variant="outline" className="border-primary/50 bg-primary/10 text-primary">
                  {synergy}
                </Badge>
              ))}
            </div>
          </div>

          {/* Mejores combinaciones */}
          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Mejores Combinaciones</h4>
            <p className="mb-3 text-xs text-muted-foreground">Combina este item con estos para máximo efecto:</p>
            <div className="grid grid-cols-3 gap-3">
              {item.bestWith.map((itemName) => {
                const relatedItem = items.find((i) => i.name === itemName) || weapons.find((w) => w.name === itemName)
                return (
                  <div
                    key={itemName}
                    className="flex flex-col items-center rounded-lg border border-border bg-secondary p-3"
                  >
                    <img
                      src={relatedItem?.image || `/placeholder.svg?height=48&width=48&query=${itemName}`}
                      alt={itemName}
                      className="mb-2 h-10 w-10 object-contain"
                    />
                    <span className="text-center text-xs font-medium text-foreground">{itemName}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

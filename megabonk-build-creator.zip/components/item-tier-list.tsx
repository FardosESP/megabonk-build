"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ItemDetailModal } from "@/components/item-detail-modal"
import { items, type Item } from "@/lib/game-data"

const tierConfig: Record<string, { color: string; bgColor: string }> = {
  S: { color: "text-yellow-500", bgColor: "bg-yellow-500/10 border-yellow-500/30" },
  A: { color: "text-primary", bgColor: "bg-primary/10 border-primary/30" },
  B: { color: "text-blue-500", bgColor: "bg-blue-500/10 border-blue-500/30" },
  C: { color: "text-gray-500", bgColor: "bg-gray-500/10 border-gray-500/30" },
}

export function ItemTierList() {
  const [selectedType, setSelectedType] = useState("Todos")
  const [selectedItem, setSelectedItem] = useState<Item | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const types = ["Todos", "Ofensivo", "Defensivo", "Utilidad", "Control", "Velocidad", "Suerte"]

  const filteredItems = selectedType === "Todos" ? items : items.filter((item) => item.type === selectedType)

  const groupedItems = filteredItems.reduce(
    (acc, item) => {
      if (!acc[item.tier]) acc[item.tier] = []
      acc[item.tier].push(item)
      return acc
    },
    {} as Record<string, typeof items>,
  )

  const handleItemClick = (item: Item) => {
    setSelectedItem(item)
    setIsModalOpen(true)
  }

  return (
    <section id="items" className="py-20">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Item Tier List</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Los mejores items del meta actual. Haz clic en cualquier item para ver sus stats y sinergias
          </p>
        </div>

        <div className="mb-8 flex justify-center">
          <Tabs value={selectedType} onValueChange={setSelectedType}>
            <TabsList className="flex-wrap bg-secondary">
              {types.map((type) => (
                <TabsTrigger
                  key={type}
                  value={type}
                  className="text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  {type}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        <div className="space-y-6">
          {(["S", "A", "B", "C"] as const).map(
            (tier) =>
              groupedItems[tier] &&
              groupedItems[tier].length > 0 && (
                <div key={tier} className={`rounded-xl border p-4 ${tierConfig[tier].bgColor}`}>
                  <div className="mb-4 flex items-center gap-3">
                    <span className={`text-2xl font-bold ${tierConfig[tier].color}`}>Tier {tier}</span>
                    <Badge className={tierConfig[tier].color + " bg-transparent"}>
                      {groupedItems[tier].length} items
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
                    {groupedItems[tier].map((item) => (
                      <Card
                        key={item.id}
                        className="cursor-pointer border-border bg-card transition-all hover:border-primary/50 hover:shadow-md hover:scale-105"
                        onClick={() => handleItemClick(item)}
                      >
                        <CardContent className="p-3">
                          <div className="mb-2 flex items-center justify-center">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="h-12 w-12 rounded-lg object-cover"
                            />
                          </div>
                          <h4 className="mb-1 text-center text-sm font-medium text-foreground">{item.name}</h4>
                          <p className="text-center text-xs text-muted-foreground line-clamp-2">{item.effect}</p>
                          <div className="mt-2 flex flex-wrap justify-center gap-1">
                            {item.stats.damage && (
                              <Badge variant="outline" className="text-[10px] border-red-500/30 text-red-400">
                                +{item.stats.damage}% DMG
                              </Badge>
                            )}
                            {item.stats.critChance && (
                              <Badge variant="outline" className="text-[10px] border-orange-500/30 text-orange-400">
                                +{item.stats.critChance}% CRIT
                              </Badge>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ),
          )}
        </div>
      </div>

      <ItemDetailModal item={selectedItem} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </section>
  )
}

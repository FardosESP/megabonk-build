import { Sword, Github, Twitter, Youtube } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border bg-background py-12">
      <div className="mx-auto max-w-7xl px-4">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Sword className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">
                MegaBonk<span className="text-primary">.gg</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              La mejor herramienta para crear y descubrir builds de MegaBonk.
            </p>
          </div>

          <div>
            <h4 className="mb-4 font-semibold text-foreground">Recursos</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Guías
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Tier Lists
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Parches
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Wiki
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-semibold text-foreground">Comunidad</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Discord
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Reddit
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Torneos
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Streamers
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-semibold text-foreground">Síguenos</h4>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground transition-colors hover:text-primary">
                <Github className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 MegaBonk.gg. No afiliado con MegaBonk oficial.</p>
        </div>
      </div>
    </footer>
  )
}

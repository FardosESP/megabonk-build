"use client"

import { useState } from "react"
import { Trophy, Eye, Heart, Clock, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BuildDetailModal } from "@/components/build-detail-modal"
import { topBuilds, type Build } from "@/lib/game-data"

const regions = ["Global", "KR", "NA", "EU", "JP", "CN"]

export function TopBuilds() {
  const [selectedRegion, setSelectedRegion] = useState("Global")
  const [selectedBuild, setSelectedBuild] = useState<Build | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const filteredBuilds =
    selectedRegion === "Global" ? topBuilds : topBuilds.filter((build) => build.region === selectedRegion)

  const handleViewBuild = (build: Build) => {
    setSelectedBuild(build)
    setIsModalOpen(true)
  }

  return (
    <section id="top-builds" className="bg-card/50 py-20">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mb-12 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <Trophy className="h-6 w-6 text-primary" />
              <h2 className="text-3xl font-bold text-foreground md:text-4xl">Top Builds Mundiales</h2>
            </div>
            <p className="text-muted-foreground">Las mejores builds usadas por los jugadores top del mundo</p>
          </div>

          <Tabs value={selectedRegion} onValueChange={setSelectedRegion}>
            <TabsList className="bg-secondary">
              {regions.map((region) => (
                <TabsTrigger
                  key={region}
                  value={region}
                  className="text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  {region}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        <div className="grid gap-6">
          {filteredBuilds.map((build, index) => (
            <Card key={build.id} className="border-border bg-card transition-all hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <div
                        className={`flex h-12 w-12 items-center justify-center rounded-full font-bold ${
                          index === 0
                            ? "bg-yellow-500 text-black"
                            : index === 1
                              ? "bg-gray-400 text-black"
                              : index === 2
                                ? "bg-amber-700 text-white"
                                : "bg-secondary text-foreground"
                        }`}
                      >
                        #{build.rank}
                      </div>
                    </div>

                    <div className="flex-1">
                      <div className="mb-2 flex flex-wrap items-center gap-2">
                        <h3 className="text-xl font-bold text-foreground">{build.name}</h3>
                        <Badge className="bg-primary/20 text-primary">{build.character}</Badge>
                        <Badge variant="outline" className="border-border text-muted-foreground">
                          {build.region}
                        </Badge>
                      </div>

                      <div className="mb-4 flex items-center gap-3">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={build.playerAvatar || "/placeholder.svg"} />
                          <AvatarFallback>{build.player[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-muted-foreground">{build.player}</span>
                        <span className="text-sm font-medium text-accent">{build.winRate}% Win Rate</span>
                      </div>

                      <div className="flex flex-wrap gap-6">
                        <div>
                          <p className="mb-1 text-xs text-muted-foreground">Armas</p>
                          <div className="flex flex-wrap gap-1">
                            {build.weapons.map((weapon) => (
                              <Badge key={weapon} variant="secondary" className="bg-secondary text-xs text-foreground">
                                {weapon}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="mb-1 text-xs text-muted-foreground">Items</p>
                          <div className="flex flex-wrap gap-1">
                            {build.items.map((item) => (
                              <Badge key={item} variant="secondary" className="bg-secondary text-xs text-foreground">
                                {item}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 lg:flex-col lg:items-end">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Eye className="h-4 w-4" /> {(build.views / 1000).toFixed(1)}K
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="h-4 w-4" /> {(build.likes / 1000).toFixed(1)}K
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" /> {build.updatedAt}
                      </span>
                    </div>
                    <Button
                      className="bg-primary text-primary-foreground hover:bg-primary/90"
                      onClick={() => handleViewBuild(build)}
                    >
                      Ver Build <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button variant="outline" size="lg" className="border-border bg-secondary text-foreground hover:bg-muted">
            Ver Todas las Builds
          </Button>
        </div>
      </div>

      <BuildDetailModal build={selectedBuild} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </section>
  )
}

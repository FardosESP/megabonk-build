"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Menu, X, Sword, Search, User, Trophy, Package, Wrench, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { searchAll } from "@/lib/game-data"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<ReturnType<typeof searchAll> | null>(null)
  const [showResults, setShowResults] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (searchQuery.length > 1) {
      const results = searchAll(searchQuery)
      setSearchResults(results)
      setShowResults(true)
    } else {
      setSearchResults(null)
      setShowResults(false)
    }
  }, [searchQuery])

  // Cerrar resultados al hacer clic fuera
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const hasResults =
    searchResults &&
    (searchResults.characters.length > 0 ||
      searchResults.items.length > 0 ||
      searchResults.weapons.length > 0 ||
      searchResults.builds.length > 0)

  const navLinks = [
    { href: "/", label: "Inicio", icon: Home },
    { href: "/characters", label: "Personajes", icon: User },
    { href: "/builds", label: "Top Builds", icon: Trophy },
    { href: "/items", label: "Items", icon: Package },
    { href: "/builder", label: "Crear Build", icon: Wrench },
  ]

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <Sword className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">
            MegaBonk<span className="text-primary">.gg</span>
          </span>
        </Link>

        {/* Navegación desktop */}
        <nav className="hidden items-center gap-6 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <link.icon className="h-4 w-4" />
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Búsqueda con resultados */}
        <div className="hidden items-center gap-4 md:flex">
          <div className="relative" ref={searchRef}>
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar personajes, items..."
              className="w-64 bg-secondary pl-9 pr-4"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => searchQuery.length > 1 && setShowResults(true)}
            />

            {/* Dropdown de resultados */}
            {showResults && hasResults && (
              <div className="absolute top-full mt-2 w-80 rounded-lg border border-border bg-card p-2 shadow-xl">
                {searchResults.characters.length > 0 && (
                  <div className="mb-2">
                    <p className="mb-1 px-2 text-xs font-semibold text-muted-foreground">Personajes</p>
                    {searchResults.characters.slice(0, 3).map((char) => (
                      <Link
                        key={char.id}
                        href={`/characters#${char.id}`}
                        className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-secondary"
                        onClick={() => setShowResults(false)}
                      >
                        <img
                          src={char.image || "/placeholder.svg"}
                          alt={char.name}
                          className="h-8 w-8 rounded-full object-cover"
                        />
                        <div>
                          <p className="text-sm font-medium text-foreground">{char.name}</p>
                          <p className="text-xs text-muted-foreground">{char.role}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                {searchResults.items.length > 0 && (
                  <div className="mb-2">
                    <p className="mb-1 px-2 text-xs font-semibold text-muted-foreground">Items</p>
                    {searchResults.items.slice(0, 3).map((item) => (
                      <Link
                        key={item.id}
                        href={`/items#${item.id}`}
                        className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-secondary"
                        onClick={() => setShowResults(false)}
                      >
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="h-8 w-8 rounded object-cover"
                        />
                        <div>
                          <p className="text-sm font-medium text-foreground">{item.name}</p>
                          <p className="text-xs text-primary">{item.effect}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                {searchResults.builds.length > 0 && (
                  <div>
                    <p className="mb-1 px-2 text-xs font-semibold text-muted-foreground">Builds</p>
                    {searchResults.builds.slice(0, 2).map((build) => (
                      <Link
                        key={build.id}
                        href={`/builds#build-${build.id}`}
                        className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-secondary"
                        onClick={() => setShowResults(false)}
                      >
                        <img
                          src={build.characterImage || "/placeholder.svg"}
                          alt={build.character}
                          className="h-8 w-8 rounded-full object-cover"
                        />
                        <div>
                          <p className="text-sm font-medium text-foreground">{build.name}</p>
                          <p className="text-xs text-muted-foreground">por {build.player}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <Link href="/builder">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Wrench className="mr-2 h-4 w-4" />
              Crear Build
            </Button>
          </Link>
        </div>

        {/* Menú móvil */}
        <button className="lg:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6 text-foreground" /> : <Menu className="h-6 w-6 text-foreground" />}
        </button>
      </div>

      {/* Menú móvil expandido */}
      {isMenuOpen && (
        <div className="border-t border-border bg-background p-4 lg:hidden">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar..."
                className="w-full bg-secondary pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <nav className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="flex items-center gap-2 rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
                onClick={() => setIsMenuOpen(false)}
              >
                <link.icon className="h-5 w-5" />
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  )
}

"use client"

import type React from "react"

import { useState, useMemo, useEffect } from "react"
import {
  Plus,
  Trash2,
  Share2,
  Download,
  Zap,
  Shield,
  Target,
  TrendingUp,
  Sparkles,
  Copy,
  Check,
  Upload,
  RotateCcw,
  Heart,
  Coins,
  Clock,
  Wind,
  Crosshair,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  characters,
  weapons,
  items,
  tomes,
  calculateBuildStats,
  getItemByName,
  getWeaponByName,
  getTomeByName,
  getCharacterById,
} from "@/lib/game-data"

const statConfig: Record<string, { icon: React.ReactNode; label: string; color: string; suffix: string }> = {
  damage: { icon: <Zap className="h-3 w-3" />, label: "Daño", color: "text-red-400", suffix: "%" },
  critChance: {
    icon: <Crosshair className="h-3 w-3" />,
    label: "Prob. Crítico",
    color: "text-orange-400",
    suffix: "%",
  },
  critDamage: { icon: <Sparkles className="h-3 w-3" />, label: "Daño Crítico", color: "text-yellow-400", suffix: "%" },
  attackSpeed: { icon: <TrendingUp className="h-3 w-3" />, label: "Vel. Ataque", color: "text-green-400", suffix: "%" },
  projectiles: { icon: <Target className="h-3 w-3" />, label: "Proyectiles", color: "text-blue-400", suffix: "" },
  size: { icon: <TrendingUp className="h-3 w-3" />, label: "Tamaño", color: "text-pink-400", suffix: "%" },
  movementSpeed: { icon: <Wind className="h-3 w-3" />, label: "Vel. Movimiento", color: "text-cyan-400", suffix: "%" },
  luck: { icon: <Sparkles className="h-3 w-3" />, label: "Suerte", color: "text-purple-400", suffix: "%" },
  armor: { icon: <Shield className="h-3 w-3" />, label: "Armadura", color: "text-gray-400", suffix: "" },
  health: { icon: <Heart className="h-3 w-3" />, label: "Salud", color: "text-green-500", suffix: "" },
  cooldown: { icon: <Clock className="h-3 w-3" />, label: "Cooldown", color: "text-blue-300", suffix: "%" },
  xpBonus: { icon: <Sparkles className="h-3 w-3" />, label: "Bonus XP", color: "text-green-300", suffix: "%" },
  goldBonus: { icon: <Coins className="h-3 w-3" />, label: "Bonus Oro", color: "text-yellow-300", suffix: "%" },
}

interface SavedBuild {
  id: string
  name: string
  character: string
  weapons: string[]
  items: string[]
  tomes: string[]
  createdAt: string
}

export function BuildCreator() {
  const [buildName, setBuildName] = useState("")
  const [selectedCharacter, setSelectedCharacter] = useState("")
  const [selectedWeapons, setSelectedWeapons] = useState<string[]>([])
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [selectedTomes, setSelectedTomes] = useState<string[]>([])
  const [showShareModal, setShowShareModal] = useState(false)
  const [showImportModal, setShowImportModal] = useState(false)
  const [showSavedBuilds, setShowSavedBuilds] = useState(false)
  const [importCode, setImportCode] = useState("")
  const [copied, setCopied] = useState(false)
  const [savedBuilds, setSavedBuilds] = useState<SavedBuild[]>([])

  useEffect(() => {
    const saved = localStorage.getItem("megabonk-builds")
    if (saved) {
      setSavedBuilds(JSON.parse(saved))
    }
  }, [])

  const buildStats = useMemo(() => {
    return calculateBuildStats(selectedWeapons, selectedItems, selectedTomes)
  }, [selectedWeapons, selectedItems, selectedTomes])

  const activeSynergies = useMemo(() => {
    const synergies: { name: string; bonus: string }[] = []
    const character = characters.find((c) => c.id === selectedCharacter)

    selectedItems.forEach((itemName) => {
      const item = getItemByName(itemName)
      if (item) {
        item.synergies.forEach((syn) => {
          if (selectedItems.includes(syn) || selectedWeapons.includes(syn) || character?.name.includes(syn)) {
            const existingIdx = synergies.findIndex((s) => s.name.includes(itemName) && s.name.includes(syn))
            if (existingIdx === -1) {
              synergies.push({
                name: `${itemName} + ${syn}`,
                bonus: "Sinergia activa!",
              })
            }
          }
        })
      }
    })

    return synergies
  }, [selectedItems, selectedWeapons, selectedCharacter])

  const addWeapon = (weapon: string) => {
    if (selectedWeapons.length < 4 && !selectedWeapons.includes(weapon)) {
      setSelectedWeapons([...selectedWeapons, weapon])
    }
  }

  const removeWeapon = (weapon: string) => {
    setSelectedWeapons(selectedWeapons.filter((w) => w !== weapon))
  }

  const addItem = (item: string) => {
    if (selectedItems.length < 6 && !selectedItems.includes(item)) {
      setSelectedItems([...selectedItems, item])
    }
  }

  const removeItem = (item: string) => {
    setSelectedItems(selectedItems.filter((i) => i !== item))
  }

  const addTome = (tome: string) => {
    if (selectedTomes.length < 4 && !selectedTomes.includes(tome)) {
      setSelectedTomes([...selectedTomes, tome])
    }
  }

  const removeTome = (tome: string) => {
    setSelectedTomes(selectedTomes.filter((t) => t !== tome))
  }

  const character = characters.find((c) => c.id === selectedCharacter)

  const generateBuildCode = () => {
    const buildData = {
      n: buildName,
      c: selectedCharacter,
      w: selectedWeapons,
      i: selectedItems,
      t: selectedTomes,
    }
    return btoa(JSON.stringify(buildData))
  }

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generateBuildCode())
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleImportBuild = () => {
    try {
      const decoded = JSON.parse(atob(importCode))
      if (decoded.n) setBuildName(decoded.n)
      if (decoded.c) setSelectedCharacter(decoded.c)
      if (decoded.w) setSelectedWeapons(decoded.w)
      if (decoded.i) setSelectedItems(decoded.i)
      if (decoded.t) setSelectedTomes(decoded.t)
      setShowImportModal(false)
      setImportCode("")
    } catch (e) {
      alert("Código de build inválido")
    }
  }

  const handleSaveBuild = () => {
    if (!buildName || !selectedCharacter) {
      alert("Necesitas un nombre y personaje para guardar la build")
      return
    }
    const newBuild: SavedBuild = {
      id: Date.now().toString(),
      name: buildName,
      character: selectedCharacter,
      weapons: selectedWeapons,
      items: selectedItems,
      tomes: selectedTomes,
      createdAt: new Date().toLocaleDateString(),
    }
    const updated = [...savedBuilds, newBuild]
    setSavedBuilds(updated)
    localStorage.setItem("megabonk-builds", JSON.stringify(updated))
    alert("Build guardada!")
  }

  const loadSavedBuild = (build: SavedBuild) => {
    setBuildName(build.name)
    setSelectedCharacter(build.character)
    setSelectedWeapons(build.weapons)
    setSelectedItems(build.items)
    setSelectedTomes(build.tomes)
    setShowSavedBuilds(false)
  }

  const deleteSavedBuild = (id: string) => {
    const updated = savedBuilds.filter((b) => b.id !== id)
    setSavedBuilds(updated)
    localStorage.setItem("megabonk-builds", JSON.stringify(updated))
  }

  const handleExport = () => {
    const buildData = {
      name: buildName || "Mi Build",
      character: character?.name || "",
      weapons: selectedWeapons,
      items: selectedItems,
      tomes: selectedTomes,
      stats: buildStats,
    }
    const blob = new Blob([JSON.stringify(buildData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${buildName || "megabonk-build"}.json`
    a.click()
  }

  const handleReset = () => {
    setBuildName("")
    setSelectedCharacter("")
    setSelectedWeapons([])
    setSelectedItems([])
    setSelectedTomes([])
  }

  return (
    <TooltipProvider>
      <section id="builder" className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Crea Tu Build</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Diseña tu build perfecta, ve estadísticas en tiempo real, y comparte con la comunidad
            </p>
          </div>

          {/* Botones de acción rápida */}
          <div className="mb-6 flex flex-wrap justify-center gap-3">
            <Button variant="outline" onClick={() => setShowImportModal(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Importar Build
            </Button>
            <Button variant="outline" onClick={() => setShowSavedBuilds(true)}>
              <Heart className="mr-2 h-4 w-4" />
              Mis Builds ({savedBuilds.length})
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Resetear
            </Button>
          </div>

          <div className="grid gap-8 lg:grid-cols-3">
            <div className="space-y-6 lg:col-span-2">
              {/* Info de la build */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Información de la Build</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="build-name" className="text-foreground">
                      Nombre de la Build
                    </Label>
                    <Input
                      id="build-name"
                      placeholder="Ej: Ice Queen Domination"
                      value={buildName}
                      onChange={(e) => setBuildName(e.target.value)}
                      className="mt-1 border-border bg-secondary text-foreground"
                    />
                  </div>

                  <div>
                    <Label className="text-foreground">Personaje</Label>
                    <Select value={selectedCharacter} onValueChange={setSelectedCharacter}>
                      <SelectTrigger className="mt-1 border-border bg-secondary text-foreground">
                        <SelectValue placeholder="Selecciona un personaje" />
                      </SelectTrigger>
                      <SelectContent className="border-border bg-card">
                        {characters.map((char) => (
                          <SelectItem key={char.id} value={char.id}>
                            <div className="flex items-center gap-2">
                              <img
                                src={char.image || "/placeholder.svg"}
                                alt={char.name}
                                className="h-6 w-6 rounded-full object-cover"
                              />
                              <span>{char.name}</span>
                              <Badge
                                className={`ml-2 text-xs ${
                                  char.tier === "S"
                                    ? "bg-yellow-500/20 text-yellow-400"
                                    : char.tier === "A"
                                      ? "bg-orange-500/20 text-orange-400"
                                      : char.tier === "B"
                                        ? "bg-blue-500/20 text-blue-400"
                                        : "bg-gray-500/20 text-gray-400"
                                }`}
                              >
                                {char.tier}
                              </Badge>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Info del personaje seleccionado */}
                  {character && (
                    <div className={`rounded-lg bg-gradient-to-r ${character.color} p-4`}>
                      <div className="flex items-center gap-4">
                        <img
                          src={character.image || "/placeholder.svg"}
                          alt={character.name}
                          className="h-16 w-16 rounded-full border-2 border-white/30 object-cover"
                        />
                        <div className="text-white">
                          <h4 className="font-bold">{character.name}</h4>
                          <p className="text-sm opacity-90">{character.role}</p>
                          <p className="mt-1 text-xs opacity-80">
                            <span className="font-medium">{character.passive}:</span> {character.passiveDesc}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Armas */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-foreground">
                    <span className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-primary" />
                      Armas
                    </span>
                    <Badge variant="outline" className="border-border text-muted-foreground">
                      {selectedWeapons.length}/4
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {selectedWeapons.map((weaponName) => {
                      const weapon = getWeaponByName(weaponName)
                      return (
                        <div
                          key={weaponName}
                          className="group relative rounded-lg border border-primary/30 bg-primary/10 p-2"
                        >
                          <button
                            onClick={() => removeWeapon(weaponName)}
                            className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 opacity-0 transition-opacity group-hover:opacity-100"
                          >
                            <Trash2 className="h-3 w-3 text-white" />
                          </button>
                          <img
                            src={weapon?.image || "/placeholder.svg"}
                            alt={weaponName}
                            className="mx-auto h-10 w-10 object-contain"
                          />
                          <p className="mt-1 text-center text-xs font-medium text-foreground">{weaponName}</p>
                          <div className="mt-1 flex flex-wrap justify-center gap-1">
                            {weapon?.stats.damage && (
                              <span className="text-[10px] text-red-400">+{weapon.stats.damage}%</span>
                            )}
                          </div>
                        </div>
                      )
                    })}
                    {selectedWeapons.length < 4 && (
                      <div className="flex h-20 items-center justify-center rounded-lg border border-dashed border-border">
                        <Plus className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {weapons
                      .filter((w) => !selectedWeapons.includes(w.name))
                      .sort((a, b) => {
                        const tierOrder = { S: 0, A: 1, B: 2, C: 3, D: 4 }
                        return tierOrder[a.tier] - tierOrder[b.tier]
                      })
                      .map((weapon) => (
                        <Tooltip key={weapon.id}>
                          <TooltipTrigger asChild>
                            <Badge
                              variant="outline"
                              className={`cursor-pointer border-border transition-colors hover:border-primary hover:bg-primary/10 ${
                                weapon.tier === "S"
                                  ? "border-yellow-500/50"
                                  : weapon.tier === "A"
                                    ? "border-orange-500/30"
                                    : ""
                              }`}
                              onClick={() => addWeapon(weapon.name)}
                            >
                              <img
                                src={weapon.image || "/placeholder.svg"}
                                alt={weapon.name}
                                className="mr-1 h-4 w-4 object-contain"
                              />
                              {weapon.name}
                              {weapon.tier === "S" && <Sparkles className="ml-1 h-3 w-3 text-yellow-500" />}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-xs border-border bg-card">
                            <div className="flex items-start gap-2">
                              <img
                                src={weapon.image || "/placeholder.svg"}
                                alt={weapon.name}
                                className="h-10 w-10 object-contain"
                              />
                              <div>
                                <p className="font-bold text-foreground">{weapon.name}</p>
                                <Badge
                                  className={`text-[10px] ${
                                    weapon.tier === "S"
                                      ? "bg-yellow-500/20 text-yellow-400"
                                      : weapon.tier === "A"
                                        ? "bg-orange-500/20 text-orange-400"
                                        : "bg-blue-500/20 text-blue-400"
                                  }`}
                                >
                                  {weapon.tier}-Tier
                                </Badge>
                              </div>
                            </div>
                            <p className="mt-2 text-xs text-muted-foreground">{weapon.description}</p>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {Object.entries(weapon.stats).map(
                                ([key, value]) =>
                                  value && (
                                    <span key={key} className={`text-xs ${statConfig[key]?.color || "text-accent"}`}>
                                      +{value}
                                      {statConfig[key]?.suffix} {statConfig[key]?.label}
                                    </span>
                                  ),
                              )}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      ))}
                  </div>
                </CardContent>
              </Card>

              {/* Items - similar estructura mejorada */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-foreground">
                    <span className="flex items-center gap-2">
                      <Package className="h-5 w-5 text-accent" />
                      Items
                    </span>
                    <Badge variant="outline" className="border-border text-muted-foreground">
                      {selectedItems.length}/6
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 grid grid-cols-3 gap-2 sm:grid-cols-6">
                    {selectedItems.map((itemName) => {
                      const item = getItemByName(itemName)
                      return (
                        <div
                          key={itemName}
                          className="group relative rounded-lg border border-accent/30 bg-accent/10 p-2"
                        >
                          <button
                            onClick={() => removeItem(itemName)}
                            className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 opacity-0 transition-opacity group-hover:opacity-100"
                          >
                            <Trash2 className="h-3 w-3 text-white" />
                          </button>
                          <img
                            src={item?.image || "/placeholder.svg"}
                            alt={itemName}
                            className="mx-auto h-8 w-8 object-contain"
                          />
                          <p className="mt-1 text-center text-[10px] font-medium text-foreground leading-tight">
                            {itemName}
                          </p>
                        </div>
                      )
                    })}
                    {Array.from({ length: Math.max(0, 6 - selectedItems.length) }).map((_, i) => (
                      <div
                        key={i}
                        className="flex h-16 items-center justify-center rounded-lg border border-dashed border-border"
                      >
                        <Plus className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>

                  {/* Items agrupados por tier */}
                  <Tabs defaultValue="S" className="w-full">
                    <TabsList className="mb-3 grid w-full grid-cols-4 bg-secondary">
                      <TabsTrigger value="S" className="text-yellow-400">
                        S-Tier
                      </TabsTrigger>
                      <TabsTrigger value="A" className="text-orange-400">
                        A-Tier
                      </TabsTrigger>
                      <TabsTrigger value="B" className="text-blue-400">
                        B-Tier
                      </TabsTrigger>
                      <TabsTrigger value="C" className="text-gray-400">
                        C-Tier
                      </TabsTrigger>
                    </TabsList>
                    {["S", "A", "B", "C"].map((tier) => (
                      <TabsContent key={tier} value={tier} className="mt-0">
                        <div className="flex flex-wrap gap-2">
                          {items
                            .filter((i) => i.tier === tier && !selectedItems.includes(i.name))
                            .map((item) => (
                              <Tooltip key={item.id}>
                                <TooltipTrigger asChild>
                                  <Badge
                                    variant="outline"
                                    className="cursor-pointer border-border transition-colors hover:border-accent hover:bg-accent/10"
                                    onClick={() => addItem(item.name)}
                                  >
                                    <img
                                      src={item.image || "/placeholder.svg"}
                                      alt={item.name}
                                      className="mr-1 h-4 w-4 object-contain"
                                    />
                                    {item.name}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent className="max-w-sm border-border bg-card">
                                  <div className="flex items-start gap-2">
                                    <img
                                      src={item.image || "/placeholder.svg"}
                                      alt={item.name}
                                      className="h-12 w-12 object-contain"
                                    />
                                    <div>
                                      <p className="font-bold text-foreground">{item.name}</p>
                                      <p className="text-xs text-primary">{item.effect}</p>
                                    </div>
                                  </div>
                                  <Separator className="my-2" />
                                  <div className="grid grid-cols-2 gap-1">
                                    {Object.entries(item.stats).map(
                                      ([key, value]) =>
                                        value && (
                                          <div key={key} className="flex items-center gap-1">
                                            {statConfig[key]?.icon}
                                            <span className={`text-xs ${statConfig[key]?.color}`}>
                                              +{value}
                                              {statConfig[key]?.suffix}
                                            </span>
                                          </div>
                                        ),
                                    )}
                                  </div>
                                  {item.bestWith.length > 0 && (
                                    <p className="mt-2 text-[10px] text-muted-foreground">
                                      Mejor con: {item.bestWith.join(", ")}
                                    </p>
                                  )}
                                </TooltipContent>
                              </Tooltip>
                            ))}
                        </div>
                      </TabsContent>
                    ))}
                  </Tabs>
                </CardContent>
              </Card>

              {/* Tomos */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-foreground">
                    <span className="flex items-center gap-2">
                      <BookIcon className="h-5 w-5 text-blue-400" />
                      Tomos
                    </span>
                    <Badge variant="outline" className="border-border text-muted-foreground">
                      {selectedTomes.length}/4
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {selectedTomes.map((tomeName) => {
                      const tome = getTomeByName(tomeName)
                      return (
                        <div
                          key={tomeName}
                          className="group relative rounded-lg border border-blue-500/30 bg-blue-500/10 p-2"
                        >
                          <button
                            onClick={() => removeTome(tomeName)}
                            className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 opacity-0 transition-opacity group-hover:opacity-100"
                          >
                            <Trash2 className="h-3 w-3 text-white" />
                          </button>
                          <img
                            src={tome?.image || "/placeholder.svg"}
                            alt={tomeName}
                            className="mx-auto h-8 w-8 object-contain"
                          />
                          <p className="mt-1 text-center text-xs font-medium text-foreground">{tomeName}</p>
                          <p className="text-center text-[10px] text-blue-400">Max Lv.{tome?.maxLevel}</p>
                        </div>
                      )
                    })}
                    {Array.from({ length: Math.max(0, 4 - selectedTomes.length) }).map((_, i) => (
                      <div
                        key={i}
                        className="flex h-20 items-center justify-center rounded-lg border border-dashed border-border"
                      >
                        <Plus className="h-5 w-5 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {tomes
                      .filter((t) => !selectedTomes.includes(t.name))
                      .map((tome) => (
                        <Tooltip key={tome.id}>
                          <TooltipTrigger asChild>
                            <Badge
                              variant="outline"
                              className="cursor-pointer border-border transition-colors hover:border-blue-500 hover:bg-blue-500/10"
                              onClick={() => addTome(tome.name)}
                            >
                              <img
                                src={tome.image || "/placeholder.svg"}
                                alt={tome.name}
                                className="mr-1 h-4 w-4 object-contain"
                              />
                              {tome.name}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent className="border-border bg-card">
                            <p className="font-bold text-foreground">{tome.name}</p>
                            <p className="text-xs text-muted-foreground">{tome.description}</p>
                            <p className="mt-1 text-xs text-blue-400">Nivel máximo: {tome.maxLevel}</p>
                          </TooltipContent>
                        </Tooltip>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Panel de vista previa */}
            <div>
              <Card className="sticky top-24 border-border bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-foreground">Vista Previa</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {character ? (
                    <div className={`rounded-lg bg-gradient-to-br ${character.color} p-4 text-center`}>
                      <img
                        src={character.image || "/placeholder.svg"}
                        alt={character.name}
                        className="mx-auto h-20 w-20 rounded-full border-2 border-white/30 object-cover"
                      />
                      <h3 className="mt-2 text-lg font-bold text-white">{character.name}</h3>
                      <p className="text-xs text-white/80">{character.passive}</p>
                    </div>
                  ) : (
                    <div className="flex h-28 items-center justify-center rounded-lg border border-dashed border-border">
                      <p className="text-sm text-muted-foreground">Selecciona un personaje</p>
                    </div>
                  )}

                  <div>
                    <h4 className="mb-1 text-sm font-medium text-foreground">{buildName || "Sin nombre"}</h4>
                  </div>

                  {/* Stats totales */}
                  <div className="rounded-lg bg-secondary p-3">
                    <h4 className="mb-2 flex items-center gap-1 text-sm font-medium text-foreground">
                      <Sparkles className="h-4 w-4 text-primary" /> Stats Totales
                    </h4>
                    <div className="grid grid-cols-2 gap-y-1.5 text-xs">
                      {Object.entries(buildStats).map(([key, value]) => {
                        if (!value || value === 0) return null
                        const config = statConfig[key]
                        return (
                          <div key={key} className="flex items-center gap-1">
                            <span className={config?.color}>{config?.icon}</span>
                            <span className="text-muted-foreground">{config?.label}:</span>
                            <span className={`font-bold ${config?.color}`}>
                              {key === "cooldown" ? value : `+${value}`}
                              {config?.suffix}
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Sinergias activas */}
                  {activeSynergies.length > 0 && (
                    <div className="rounded-lg border border-accent/30 bg-accent/10 p-3">
                      <h4 className="mb-2 flex items-center gap-1 text-sm font-medium text-accent">
                        <Sparkles className="h-4 w-4" /> Sinergias Activas
                      </h4>
                      <div className="space-y-1">
                        {activeSynergies.map((syn, i) => (
                          <p key={i} className="text-xs text-accent">
                            {syn.name}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Resumen del equipo */}
                  <div className="space-y-2">
                    {selectedWeapons.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground">Armas:</p>
                        <p className="text-xs text-foreground">{selectedWeapons.join(", ")}</p>
                      </div>
                    )}
                    {selectedItems.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground">Items:</p>
                        <p className="text-xs text-foreground">{selectedItems.join(", ")}</p>
                      </div>
                    )}
                    {selectedTomes.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground">Tomos:</p>
                        <p className="text-xs text-foreground">{selectedTomes.join(", ")}</p>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Botones de acción */}
                  <div className="grid grid-cols-2 gap-2">
                    <Button onClick={handleSaveBuild} variant="outline" size="sm">
                      <Heart className="mr-1 h-3 w-3" /> Guardar
                    </Button>
                    <Button onClick={() => setShowShareModal(true)} variant="outline" size="sm">
                      <Share2 className="mr-1 h-3 w-3" /> Compartir
                    </Button>
                    <Button onClick={handleExport} variant="outline" size="sm" className="col-span-2 bg-transparent">
                      <Download className="mr-1 h-3 w-3" /> Exportar JSON
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Modal Compartir */}
      <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
        <DialogContent className="border-border bg-card">
          <DialogHeader>
            <DialogTitle className="text-foreground">Compartir Build</DialogTitle>
            <DialogDescription>Copia este código para compartir tu build</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg bg-secondary p-3">
              <code className="break-all text-xs text-foreground">{generateBuildCode()}</code>
            </div>
            <Button onClick={handleCopyCode} className="w-full">
              {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? "Copiado!" : "Copiar código"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Importar */}
      <Dialog open={showImportModal} onOpenChange={setShowImportModal}>
        <DialogContent className="border-border bg-card">
          <DialogHeader>
            <DialogTitle className="text-foreground">Importar Build</DialogTitle>
            <DialogDescription>Pega el código de una build compartida</DialogDescription>
          </DialogHeader>
          <Textarea
            placeholder="Pega el código aquí..."
            value={importCode}
            onChange={(e) => setImportCode(e.target.value)}
            className="min-h-24 border-border bg-secondary"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleImportBuild}>Importar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal Builds Guardadas */}
      <Dialog open={showSavedBuilds} onOpenChange={setShowSavedBuilds}>
        <DialogContent className="max-h-[80vh] overflow-y-auto border-border bg-card sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-foreground">Mis Builds Guardadas</DialogTitle>
          </DialogHeader>
          {savedBuilds.length === 0 ? (
            <p className="py-8 text-center text-muted-foreground">No tienes builds guardadas aún</p>
          ) : (
            <div className="space-y-2">
              {savedBuilds.map((build) => {
                const char = getCharacterById(build.character)
                return (
                  <div
                    key={build.id}
                    className="flex items-center gap-3 rounded-lg border border-border bg-secondary p-3"
                  >
                    <img
                      src={char?.image || "/placeholder.svg"}
                      alt={char?.name}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground">{build.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {char?.name} - {build.createdAt}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => loadSavedBuild(build)}>
                        Cargar
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => deleteSavedBuild(build.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  )
}

// Icono de libro simple
function BookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  )
}

function Package({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="m7.5 4.27 9 5.15" />
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  )
}

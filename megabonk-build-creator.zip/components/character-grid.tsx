"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { CharacterDetailModal } from "@/components/character-detail-modal"
import { characters, type Character } from "@/lib/game-data"

const tierColors: Record<string, string> = {
  S: "bg-gradient-to-r from-yellow-500 to-amber-500 text-black",
  A: "bg-gradient-to-r from-primary to-orange-500 text-black",
  B: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white",
  C: "bg-gradient-to-r from-gray-500 to-gray-600 text-white",
}

export function CharacterGrid() {
  const [selectedTier, setSelectedTier] = useState<string | null>(null)
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const filteredCharacters = selectedTier ? characters.filter((c) => c.tier === selectedTier) : characters

  const handleCharacterClick = (character: Character) => {
    setSelectedCharacter(character)
    setIsModalOpen(true)
  }

  return (
    <section id="characters" className="py-20">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Personajes</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Haz clic en cualquier personaje para ver sus stats, builds recomendadas y sinergias
          </p>
        </div>

        <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
          <Badge
            onClick={() => setSelectedTier(null)}
            className={`cursor-pointer px-4 py-2 text-sm transition-all ${
              selectedTier === null
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-muted"
            }`}
          >
            Todos
          </Badge>
          {["S", "A", "B", "C"].map((tier) => (
            <Badge
              key={tier}
              onClick={() => setSelectedTier(tier)}
              className={`cursor-pointer px-4 py-2 text-sm transition-all ${
                selectedTier === tier ? tierColors[tier] : "bg-secondary text-foreground hover:bg-muted"
              }`}
            >
              Tier {tier}
            </Badge>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {filteredCharacters.map((character) => (
            <Card
              key={character.id}
              onClick={() => handleCharacterClick(character)}
              className="group cursor-pointer overflow-hidden border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10 hover:scale-[1.02]"
            >
              <div className={`relative h-48 bg-gradient-to-br ${character.color}`}>
                <img
                  src={character.image || "/placeholder.svg"}
                  alt={character.name}
                  className="h-full w-full object-cover mix-blend-overlay transition-transform group-hover:scale-105"
                />
                <Badge className={`absolute right-3 top-3 ${tierColors[character.tier]}`}>{character.tier}</Badge>
              </div>
              <CardContent className="p-4">
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="text-lg font-bold text-foreground">{character.name}</h3>
                  <Badge variant="outline" className="border-border text-muted-foreground">
                    {character.role}
                  </Badge>
                </div>
                <div className="mb-3 rounded-lg bg-secondary p-2">
                  <p className="text-xs font-medium text-primary">{character.passive}</p>
                  <p className="text-xs text-muted-foreground">{character.passiveDesc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Arma inicial:</span>
                  <span className="text-xs font-medium text-foreground">{character.starterWeapon}</span>
                </div>
                <div className="mt-3 grid grid-cols-4 gap-1 text-center">
                  <div className="rounded bg-red-500/10 p-1">
                    <p className="text-[10px] text-muted-foreground">HP</p>
                    <p className="text-xs font-bold text-red-400">{character.stats.health}</p>
                  </div>
                  <div className="rounded bg-cyan-500/10 p-1">
                    <p className="text-[10px] text-muted-foreground">SPD</p>
                    <p className="text-xs font-bold text-cyan-400">{character.stats.speed}</p>
                  </div>
                  <div className="rounded bg-yellow-500/10 p-1">
                    <p className="text-[10px] text-muted-foreground">DMG</p>
                    <p className="text-xs font-bold text-yellow-400">{character.stats.damage}</p>
                  </div>
                  <div className="rounded bg-gray-500/10 p-1">
                    <p className="text-[10px] text-muted-foreground">ARM</p>
                    <p className="text-xs font-bold text-gray-400">{character.stats.armor}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <CharacterDetailModal character={selectedCharacter} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </section>
  )
}

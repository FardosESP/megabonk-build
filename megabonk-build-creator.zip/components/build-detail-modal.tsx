"use client"

import { Trophy, Eye, Heart, Clock, User, Globe, Zap, Shield, Target, TrendingUp, Sparkles } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  type Build,
  getItemByName,
  getWeaponByName,
  getTomeByName,
  getCharacterByName,
  calculateBuildStats,
} from "@/lib/game-data"

interface BuildDetailModalProps {
  build: Build | null
  isOpen: boolean
  onClose: () => void
}

const difficultyColors: Record<string, string> = {
  Facil: "bg-green-500/20 text-green-400",
  Media: "bg-yellow-500/20 text-yellow-400",
  Dificil: "bg-red-500/20 text-red-400",
}

export function BuildDetailModal({ build, isOpen, onClose }: BuildDetailModalProps) {
  if (!build) return null

  const character = getCharacterByName(build.character)
  const buildStats = calculateBuildStats(build.weapons, build.items, build.tomes)

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto border-border bg-card sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-start gap-4">
            <div className="relative">
              <img
                src={build.characterImage || "/placeholder.svg"}
                alt={build.character}
                className="h-24 w-24 rounded-xl border-2 border-primary object-cover"
              />
              <div className="absolute -right-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full bg-yellow-500 font-bold text-black">
                #{build.rank}
              </div>
            </div>
            <div className="flex-1">
              <DialogTitle className="mb-2 text-2xl font-bold text-foreground">{build.name}</DialogTitle>
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <Badge className="bg-primary/20 text-primary">{build.character}</Badge>
                <Badge className={difficultyColors[build.difficulty]}>{build.difficulty}</Badge>
                <Badge variant="outline" className="border-border">
                  <Globe className="mr-1 h-3 w-3" /> {build.region}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <User className="h-4 w-4" /> {build.player}
                </span>
                <span className="flex items-center gap-1 font-medium text-accent">
                  <Trophy className="h-4 w-4" /> {build.winRate}% Win Rate
                </span>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-4 flex items-center gap-6 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Eye className="h-4 w-4" /> {(build.views / 1000).toFixed(1)}K vistas
          </span>
          <span className="flex items-center gap-1">
            <Heart className="h-4 w-4" /> {(build.likes / 1000).toFixed(1)}K likes
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-4 w-4" /> {build.updatedAt}
          </span>
        </div>

        <Separator className="my-4 bg-border" />

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="w-full bg-secondary">
            <TabsTrigger value="overview" className="flex-1">
              Vista General
            </TabsTrigger>
            <TabsTrigger value="items" className="flex-1">
              Equipamiento
            </TabsTrigger>
            <TabsTrigger value="guide" className="flex-1">
              Guía
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4 space-y-4">
            {/* Descripción */}
            <div className="rounded-lg bg-secondary p-4">
              <p className="text-sm text-foreground">{build.description}</p>
            </div>

            {/* Estilo de juego */}
            <div>
              <h4 className="mb-2 text-sm font-semibold text-foreground">Estilo de Juego</h4>
              <p className="text-sm text-muted-foreground">{build.playstyle}</p>
            </div>

            {/* Stats totales de la build */}
            <div>
              <h4 className="mb-3 text-sm font-semibold text-foreground">Estadísticas Combinadas</h4>
              <div className="grid grid-cols-3 gap-3">
                {buildStats.damage > 0 && (
                  <div className="rounded-lg bg-red-500/10 p-3 text-center">
                    <Zap className="mx-auto mb-1 h-5 w-5 text-red-400" />
                    <p className="text-xs text-muted-foreground">Daño</p>
                    <p className="text-lg font-bold text-red-400">+{buildStats.damage}%</p>
                  </div>
                )}
                {buildStats.critChance > 0 && (
                  <div className="rounded-lg bg-orange-500/10 p-3 text-center">
                    <Target className="mx-auto mb-1 h-5 w-5 text-orange-400" />
                    <p className="text-xs text-muted-foreground">Crítico</p>
                    <p className="text-lg font-bold text-orange-400">+{buildStats.critChance}%</p>
                  </div>
                )}
                {buildStats.attackSpeed > 0 && (
                  <div className="rounded-lg bg-green-500/10 p-3 text-center">
                    <TrendingUp className="mx-auto mb-1 h-5 w-5 text-green-400" />
                    <p className="text-xs text-muted-foreground">Vel. Ataque</p>
                    <p className="text-lg font-bold text-green-400">+{buildStats.attackSpeed}%</p>
                  </div>
                )}
                {buildStats.projectiles > 0 && (
                  <div className="rounded-lg bg-blue-500/10 p-3 text-center">
                    <Sparkles className="mx-auto mb-1 h-5 w-5 text-blue-400" />
                    <p className="text-xs text-muted-foreground">Proyectiles</p>
                    <p className="text-lg font-bold text-blue-400">+{buildStats.projectiles}</p>
                  </div>
                )}
                {buildStats.armor > 0 && (
                  <div className="rounded-lg bg-gray-500/10 p-3 text-center">
                    <Shield className="mx-auto mb-1 h-5 w-5 text-gray-400" />
                    <p className="text-xs text-muted-foreground">Armadura</p>
                    <p className="text-lg font-bold text-gray-400">+{buildStats.armor}</p>
                  </div>
                )}
                {buildStats.movementSpeed > 0 && (
                  <div className="rounded-lg bg-cyan-500/10 p-3 text-center">
                    <TrendingUp className="mx-auto mb-1 h-5 w-5 text-cyan-400" />
                    <p className="text-xs text-muted-foreground">Velocidad</p>
                    <p className="text-lg font-bold text-cyan-400">+{buildStats.movementSpeed}%</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="items" className="mt-4 space-y-6">
            {/* Armas */}
            <div>
              <h4 className="mb-3 text-sm font-semibold text-foreground">Armas ({build.weapons.length}/4)</h4>
              <div className="grid grid-cols-2 gap-3">
                {build.weapons.map((weaponName, index) => {
                  const weapon = getWeaponByName(weaponName)
                  return (
                    <div
                      key={weaponName}
                      className="flex items-center gap-3 rounded-lg border border-border bg-secondary p-3"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
                        <img
                          src={weapon?.image || `/placeholder.svg?height=40&width=40&query=${weaponName} weapon`}
                          alt={weaponName}
                          className="h-10 w-10 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{weaponName}</p>
                        <p className="text-xs text-muted-foreground">{weapon?.type || "Arma"}</p>
                        {index === 0 && <Badge className="mt-1 bg-primary/20 text-xs text-primary">Inicial</Badge>}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Items */}
            <div>
              <h4 className="mb-3 text-sm font-semibold text-foreground">Items ({build.items.length}/6)</h4>
              <div className="grid grid-cols-2 gap-3">
                {build.items.map((itemName) => {
                  const item = getItemByName(itemName)
                  return (
                    <div
                      key={itemName}
                      className="flex items-center gap-3 rounded-lg border border-border bg-secondary p-3"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20">
                        <img
                          src={item?.image || `/placeholder.svg?height=40&width=40&query=${itemName} item`}
                          alt={itemName}
                          className="h-10 w-10 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{itemName}</p>
                        <p className="text-xs text-muted-foreground">{item?.effect || ""}</p>
                        {item && (
                          <Badge
                            className={`mt-1 text-xs ${
                              item.tier === "S"
                                ? "bg-yellow-500/20 text-yellow-400"
                                : item.tier === "A"
                                  ? "bg-primary/20 text-primary"
                                  : "bg-blue-500/20 text-blue-400"
                            }`}
                          >
                            Tier {item.tier}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Tomos */}
            <div>
              <h4 className="mb-3 text-sm font-semibold text-foreground">Tomos ({build.tomes.length}/4)</h4>
              <div className="grid grid-cols-2 gap-3">
                {build.tomes.map((tomeName) => {
                  const tome = getTomeByName(tomeName)
                  return (
                    <div
                      key={tomeName}
                      className="flex items-center gap-3 rounded-lg border border-border bg-secondary p-3"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-500/20">
                        <img
                          src={tome?.image || `/placeholder.svg?height=40&width=40&query=${tomeName} book tome`}
                          alt={tomeName}
                          className="h-10 w-10 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{tomeName}</p>
                        <p className="text-xs text-muted-foreground">{tome?.description || ""}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="guide" className="mt-4 space-y-4">
            <div>
              <h4 className="mb-2 flex items-center gap-2 text-sm font-semibold text-green-400">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-green-500/20">1</span>
                Early Game
              </h4>
              <p className="ml-8 text-sm text-muted-foreground">{build.gamePhase.early}</p>
            </div>

            <div>
              <h4 className="mb-2 flex items-center gap-2 text-sm font-semibold text-yellow-400">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-yellow-500/20">2</span>
                Mid Game
              </h4>
              <p className="ml-8 text-sm text-muted-foreground">{build.gamePhase.mid}</p>
            </div>

            <div>
              <h4 className="mb-2 flex items-center gap-2 text-sm font-semibold text-red-400">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-red-500/20">3</span>
                Late Game
              </h4>
              <p className="ml-8 text-sm text-muted-foreground">{build.gamePhase.late}</p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
